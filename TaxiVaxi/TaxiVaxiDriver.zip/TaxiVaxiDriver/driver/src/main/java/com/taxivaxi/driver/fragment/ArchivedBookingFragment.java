package com.taxivaxi.driver.fragment;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.adapter.ArchivedBookingAdapter;
import com.taxivaxi.driver.adapter.UpcomingBookingAdapter;
import com.taxivaxi.driver.models.archivedbooking.Booking;
import com.taxivaxi.driver.utility.GsonStringConvertor;
import com.taxivaxi.driver.viewmodels.ArchivedBookingViewModel;
import com.taxivaxi.driver.viewmodels.CurrentBookingViewModel;
import com.taxivaxi.driver.viewmodels.DriverInfoViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class ArchivedBookingFragment extends Fragment implements ArchivedBookingAdapter.RecyclerViewEventListener ,SwipeRefreshLayout.OnRefreshListener {

    ArchivedBookingViewModel archivedBookingViewModel;
    DriverInfoViewModel driverInfoViewModel;
    ProgressBar progressBar;
    View view;
    List<Booking> bookingList;
    ArchivedBookingAdapter archivedBookingAdapter;
    CurrentBookingViewModel currentBookingViewModel;
    RecyclerView recyclerView;
    SwipeRefreshLayout swipeRefreshLayout;


    public ArchivedBookingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_archived_booking, container, false);
        progressBar=view.findViewById(R.id.progressBar);
        recyclerView=view.findViewById(R.id.archived_recycleview);
        swipeRefreshLayout=view.findViewById(R.id.archived_swipe_refresh_layout);

        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setRefreshing(true);

        archivedBookingViewModel= ViewModelProviders.of(this).get(ArchivedBookingViewModel.class);
        driverInfoViewModel=ViewModelProviders.of(this).get(DriverInfoViewModel.class);

        bookingList=new ArrayList<>();
        archivedBookingAdapter =new ArchivedBookingAdapter(this,bookingList);
        //progressBar.setVisibility(View.VISIBLE);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext(),
                LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(archivedBookingAdapter);

        archivedBookingViewModel.getArchivedBookingList().observe(this, new Observer<List<Booking>>() {
            @Override
            public void onChanged(@Nullable List<Booking> bookings) {
                swipeRefreshLayout.setRefreshing(false);
                Log.d("Booking", GsonStringConvertor.gsonToString(bookings));
                if (bookings.size()>0) {
                    bookingList.clear();
                    bookingList.addAll(bookings);
                    archivedBookingAdapter.notifyDataSetChanged();
                }
            }
        });

        archivedBookingViewModel.getError().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                swipeRefreshLayout.setRefreshing(false);
                //progressBar.setVisibility(View.GONE);
                Log.e("Error",s);
            }
        });

        archivedBookingViewModel.getArchivedBookings(driverInfoViewModel.getAccessToken().getValue());

        return view;
    }


    @Override
    public void onDetailsClicked(Booking booking) {

    }

    @Override
    public void onRefresh() {
        archivedBookingViewModel.getArchivedBookings(driverInfoViewModel.getAccessToken().getValue());
    }
}
