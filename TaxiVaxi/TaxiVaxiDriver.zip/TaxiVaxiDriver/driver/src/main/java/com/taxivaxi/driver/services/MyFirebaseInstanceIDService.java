package com.taxivaxi.driver.services;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.taxivaxi.driver.repository.LoginRepository;
import com.taxivaxi.driver.repository.UpdateFcmTokenRepository;

/**
 * Created by sandeep on 22/2/18.
 */

public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {

    LoginRepository loginRepository;
    UpdateFcmTokenRepository updateFcmTokenRepository;

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        loginRepository=new LoginRepository(getApplication());
        updateFcmTokenRepository=new UpdateFcmTokenRepository(getApplication());
        String token= FirebaseInstanceId.getInstance().getToken();
        Log.d("FcmToken",token);

        updateFcmTokenRepository.updateFcmToken(loginRepository.getAccessToken().getValue(),"driver",token);

    }
}
