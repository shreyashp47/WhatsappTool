package com.taxivaxi.driver.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

/**
 * Created by sandeep on 9/11/17.
 */

public class CurrentTripViewModel extends AndroidViewModel {
    public CurrentTripViewModel(@NonNull Application application) {
        super(application);
    }
}
