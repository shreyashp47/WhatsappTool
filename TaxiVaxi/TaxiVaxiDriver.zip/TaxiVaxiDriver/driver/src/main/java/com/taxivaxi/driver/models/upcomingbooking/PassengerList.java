package com.taxivaxi.driver.models.upcomingbooking;

import java.util.ArrayList;

/**
 * Created by sandeep on 26/2/18.
 */

public class PassengerList {
    ArrayList<Passenger> passengers;

    public ArrayList<Passenger> getPassengers() {
        return passengers;
    }

    public void setPassengers(ArrayList<Passenger> passengers) {
        this.passengers = passengers;
    }
}
