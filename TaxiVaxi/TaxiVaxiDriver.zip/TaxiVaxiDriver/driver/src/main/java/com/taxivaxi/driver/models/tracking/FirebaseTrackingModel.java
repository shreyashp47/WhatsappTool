package com.taxivaxi.driver.models.tracking;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by sandeep on 15/9/17.
 */
@IgnoreExtraProperties
public class FirebaseTrackingModel {
    String senderId;
    String latitude;
    String longitude;
    String eot;
    String bearing;
    String tripStatus;

    public FirebaseTrackingModel(String senderId, String latitude, String longitude) {
        this.senderId = senderId;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public FirebaseTrackingModel(String senderId, String latitude, String longitude,String eot) {
        this.senderId = senderId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.eot=eot;
    }

    public FirebaseTrackingModel(String senderId, String latitude, String longitude,String eot,String bearing,String tripStatus) {
        this.senderId = senderId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.eot=eot;
        this.bearing=bearing;
        this.tripStatus=tripStatus;
    }

    @Exclude
    public Map<String,Object> toMap(){
        HashMap<String,Object> hashMap=new HashMap<>();
        hashMap.put("senderId",senderId);
        hashMap.put("latitude",latitude);
        hashMap.put("longitude",longitude);
        hashMap.put("eot",eot);
        return hashMap;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getEot() {
        return eot;
    }

    public void setEot(String eot) {
        this.eot = eot;
    }

    public String getBearing() {
        return bearing;
    }

    public void setBearing(String bearing) {
        this.bearing = bearing;
    }

    public String getTripStatus() {
        return tripStatus;
    }

    public void setTripStatus(String tripStatus) {
        this.tripStatus = tripStatus;
    }
}
