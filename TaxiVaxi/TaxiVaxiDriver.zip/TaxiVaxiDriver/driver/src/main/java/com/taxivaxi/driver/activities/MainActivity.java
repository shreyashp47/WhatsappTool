package com.taxivaxi.driver.activities;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.ResultReceiver;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.maps.android.PolyUtil;
import com.taxivaxi.driver.R;
import com.taxivaxi.driver.adapter.CallUserAdapter;
import com.taxivaxi.driver.eventlistener.eventclass.LocationChangeClass;
import com.taxivaxi.driver.eventlistener.eventinterface.LocationChangeListener;
import com.taxivaxi.driver.fragment.BookingCompletedFragment;
import com.taxivaxi.driver.fragment.EndJourneyDialog;
import com.taxivaxi.driver.fragment.JourneyStartedFromGarageDialog;
import com.taxivaxi.driver.fragment.PhoneBottomSheet;
import com.taxivaxi.driver.fragment.StartJourneyDialog;
import com.taxivaxi.driver.models.distancetime.EndDistanceTime;
import com.taxivaxi.driver.models.distancetime.EstimateDistanceTime;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.services.FetchLocationIntentService;
import com.taxivaxi.driver.services.FloatingHeadDialog;
import com.taxivaxi.driver.services.GeofenceTransitionsIntentService;
import com.taxivaxi.driver.tracking.LocationService;
import com.taxivaxi.driver.utility.GsonStringConvertor;
import com.taxivaxi.driver.utility.NetworkStatus;
import com.taxivaxi.driver.viewmodels.CurrentBookingViewModel;
import com.taxivaxi.driver.viewmodels.DriverInfoViewModel;
import com.taxivaxi.driver.viewmodels.GoogleMapsDirectionViewModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener, LocationChangeListener
        , GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks, ResultCallback<LocationSettingsResult>
        , LocationListener, StartJourneyDialog.StartRideListener, EndJourneyDialog.OnRideEndListener, JourneyStartedFromGarageDialog.OnStartFromGarageClicked{

    GoogleMap mMap;  //to plot locations of vehicle, pickupLocation and deop location
    ImageView navigationButton; //button to start navigation through google maps.
    Button actionButton; //Button to get driver's action like started from garage, arrived at pickup location etc.
    Button pauseResumeButton;
    TextView userNames;//TextView to show names of the users.
    TextView tripType;// TexView to denote "PICKUP" user or "DROP" user.
    LatLng dropCityLatLng, pickUpCityLatLng; //Lat-Lng of pickup and drop cities.
    LocationFromGeoCoderReceiver locationFromGeoCoderReceiver; //Receiver to get Lat-lng from place/address.
    Marker pickUpMarker;//Google map marker to plot pickup location.
    Marker dropMarker; //Google map marker to plot drop location.
    Marker currentMarker; //Google map marker to plot current location of the vehicle.
    String eta; // Estimate time of arrival at pickup or drop location.
    Booking booking; // Booking object which driver can start or has already started.
    TextView pickupPoint;// TextView which shows pickup or drop location according to the status of trip.
    String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION};//permission array for location.
    CurrentBookingViewModel currentBookingViewModel;// currentBookingViewModel object to store data of a current booking.
    DriverInfoViewModel driverInfoViewModel;//object that contains information about driver.
    GoogleMapsDirectionViewModel googleMapsDirectionViewModel; //viewModel to interact with google apis.
    private final int PERMISSION_CODE = 101;
    GoogleApiClient mGoogleApiClient;// googleApiClient to access location services.
    final int REQUEST_CHECK_SETTINGS = 2; //Request code for checking settings.
    final int REQUEST_OVERLAY_SETTING = 11;//Request code for requesting screen overlay permission.
    protected LocationSettingsRequest mLocationSettingsRequest; //object to access LocationSettingRequest.
    String[] status = {"Start from garage", "Arrived at Pickup Location", "Start Trip", "Reached Destination"};//status shown on action button.
    int tripStatus; // integer to save trip status in the form of integer.
    Location currentLocation;// Location object to store currentLocation.
    LatLng garageLocation;  // LatLng object to store garageLocation.
    StartJourneyDialog startJourneyDialog; // Dialog to show when driver starts journey.
    EndJourneyDialog endJourneyDialog; // Dialog to show when driver clicks on end journey.
    SharedPreferences trackPreference; // SharedPreference to store tracking information.
    int enableButton = 0;
    int enableButtonDrop = 0;  //to enable action button after start trip is called and drop location and currebt location are plotted and animated
    double measuredDistance = 0; //distance travelled calculated by using location locally.

    boolean hasEnteredPickupGeoFence = false; //to know whether driver has entered in 500 m range of pickup location.
    private GeofencingClient geofencingClient;//GeofencingClient to add geofence to pickuplocation.
    List<Geofence> geofenceList; //Geofence list to add location to geofence;
    PendingIntent mGeofencePendingIntent; //Pending intent for GeofenceTransitionService
    ArrayList<LatLng> pathLatLng;

    JourneyStartedFromGarageDialog journeyStartedFromGarageDialog;//Dialog to show JourneyStartedFromGarageDialog.


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // getWindow().setStatusBarColor(getResources().getColor(R.color.backgroundGrey));
        setContentView(R.layout.activity_main);
        // Toolbar myToolbar =findViewById(R.id.my_toolbar);
        //setSupportActionBar(myToolbar);
        navigationButton = findViewById(R.id.startNavigationButton);
        actionButton = findViewById(R.id.tripActionButton);
        userNames = findViewById(R.id.userName);
        pickupPoint = findViewById(R.id.location);
        pickupPoint = findViewById(R.id.location);
        tripType = findViewById(R.id.tripType);
        pauseResumeButton=findViewById(R.id.pause_resume);

        pauseResumeButton.setVisibility(View.GONE);

        pickupPoint.setOnClickListener(this);
        //pauseResumeButton.setOnClickListener(this);

        googleMapsDirectionViewModel = ViewModelProviders.of(this).get(GoogleMapsDirectionViewModel.class);
        currentBookingViewModel = ViewModelProviders.of(this).get(CurrentBookingViewModel.class);
        driverInfoViewModel = ViewModelProviders.of(this).get(DriverInfoViewModel.class);

        trackPreference = getSharedPreferences("trackingPref", MODE_PRIVATE);

        startJourneyDialog = new StartJourneyDialog();
        startJourneyDialog.addStartRideListener(this);

        journeyStartedFromGarageDialog=new JourneyStartedFromGarageDialog();
        journeyStartedFromGarageDialog.registerOnStartFromGarageClicked(this);


        locationFromGeoCoderReceiver = new LocationFromGeoCoderReceiver(new Handler());
        geofencingClient = LocationServices.getGeofencingClient(this);
        geofenceList=new ArrayList<>();

        endJourneyDialog = new EndJourneyDialog();
        endJourneyDialog.setOnRideEndListener(this);

        actionButton.setEnabled(false);

        Intent intent = getIntent();
        if (intent != null) {
            if (!intent.getBooleanExtra("fromNotification",false)) {
                booking = GsonStringConvertor.stringToGson(intent.getStringExtra("bookingInfo"), Booking.class);
            }
        } else {
            finish();
        }

        if (currentBookingViewModel.getCurrentBooking().getValue()!=null){
            booking=currentBookingViewModel.getCurrentBooking().getValue();
        }

        Log.d("booking",GsonStringConvertor.gsonToString(booking));

       // Log.d("Passenger", "sandeep" + GsonStringConvertor.gsonToString(booking.getPassengers()));

        currentBookingViewModel.getTripStatus().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                tripStatus = Integer.parseInt(s);
                actionButton.setText(status[tripStatus]);
                if (tripStatus<1){
                    pauseResumeButton.setVisibility(View.GONE);
                }
                if (tripStatus >= 1) {
                    if (!currentBookingViewModel.getIsPaused()) {
                        startService(new Intent(MainActivity.this, LocationService.class));
                        pauseResumeButton.setText("Pause Trip");
                    }
                    else {
                        pauseResumeButton.setText("Resume Trip");
                        actionButton.setVisibility(View.GONE);
                    }
                    pauseResumeButton.setVisibility(View.GONE);
                }
                if (Integer.parseInt(s) < 3) {
                    tripType.setText("PICK UP");
                    pickupPoint.setText(booking.getPickupLocation());
                } else {
                    tripType.setText("DROP");
                    if (booking.getDropLocation() != null && booking.getDropLocation().length() > 1) {
                        pickupPoint.setText(booking.getDropLocation());
                        Intent dropIntent = new Intent(MainActivity.this, FetchLocationIntentService.class);
                        dropIntent.putExtra("resultCode", "512");
                        dropIntent.putExtra("receiver", locationFromGeoCoderReceiver);
                        dropIntent.putExtra("location", booking.getDropLocation());
                        startService(dropIntent);
                    } else {
                        actionButton.setText(status[tripStatus]);
                        actionButton.setEnabled(true);
                        eta = null;
                    }
                    if (pickUpMarker != null) {
                        pickUpMarker.remove();
                    }
                }

            }
        });


        currentBookingViewModel.getError().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                actionButton.setEnabled(true);
                if (s != null) {
                    Snackbar.make(findViewById(android.R.id.content), s, Snackbar.LENGTH_SHORT).show();
                }
            }
        });


        currentBookingViewModel.getHasReachedPickupPoint().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean aBoolean) {
                if (aBoolean ){
                    Toast.makeText(MainActivity.this, "Geofencing Status Entered in Fence", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Geofencing Status not in Fence", Toast.LENGTH_LONG).show();
                }
                hasEnteredPickupGeoFence = aBoolean;
            }
        });


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.maps);
        mapFragment.getMapAsync(this);

        LocationChangeClass.addLocationChangeLisetener(this);

        userNames.setText(booking.getPassengers().get(0).peopleName);

        googleMapsDirectionViewModel.getPolyLine().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                if (s != null) {
                    setPolyLine(s);
                }
            }
        });

        googleMapsDirectionViewModel.getEndDistanceTime().observe(this, new Observer<EndDistanceTime>() {
            @Override
            public void onChanged(@Nullable EndDistanceTime endDistanceTime) {
                if (!endJourneyDialog.isAdded()&&endDistanceTime!=null && endDistanceTime.getJourneyDistanceTime()!=null && endDistanceTime.getGarageDistanceTime()!=null){
                    Log.d("End Estimate Distance",GsonStringConvertor.gsonToString(endDistanceTime));
                    Bundle bundle = new Bundle();
                    bundle.putString("endGarageDistance", endDistanceTime.getGarageDistanceTime().getEstimateDistance());
                    bundle.putString("endGarageTime",endDistanceTime.getGarageDistanceTime().getEstimateTime());
                    bundle.putString("journeyDistance", endDistanceTime.getJourneyDistanceTime().getEstimateDistance());
                    bundle.putString("journeyTime",endDistanceTime.getJourneyDistanceTime().getEstimateTime());
                    endJourneyDialog.setArguments(bundle);
                    endJourneyDialog.show(getSupportFragmentManager(), "End Dialog");
                }
            }
        });

        currentBookingViewModel.getHasReachedPickupPoint().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean aBoolean) {
                hasEnteredPickupGeoFence=aBoolean;
                Log.d("Driver Arrived",aBoolean+"");
            }
        });

        currentBookingViewModel.getStatus().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                Log.d("Status", s);
                switch (s) {
                    case "driver started successfully":
                        tripStatus = 1;
                        actionButton.setText(status[tripStatus]);
                        currentBookingViewModel.setGarageLocation(garageLocation);
                        currentBookingViewModel.setTripStatus("" + tripStatus);
                        currentBookingViewModel.setCurrentBooking(GsonStringConvertor.gsonToString(booking));
                        trackPreference.edit().putString("bookingId", booking.getBookingId()).commit();
                        trackPreference.edit().putString("tripStatus", "1").commit();
                        trackPreference.edit().putString("bookingInfo",GsonStringConvertor.gsonToString(booking)).commit();
                        startService(new Intent(MainActivity.this, LocationService.class));
                        actionButton.setEnabled(true);
                        currentBookingViewModel.reSetStatus();
                        geofenceList.add(new Geofence.Builder()
                                .setRequestId("pickupFence")
                                .setCircularRegion(
                                        pickUpMarker.getPosition().latitude,
                                        pickUpMarker.getPosition().longitude,
                                        150)
                                .setExpirationDuration(900000)
                                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
                                .build());
                        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            Log.d("GeoFence","Added");
                            geofencingClient.addGeofences(getGeofencingRequest(), getGeofencePendingIntent())
                                    .addOnSuccessListener(MainActivity.this, new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d("Geofencing ","Added");
                                        }
                                    })
                                    .addOnFailureListener(MainActivity.this, new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.d("Geofencing ","Error");
                                        }
                                    });
                        }
                        else {
                            Log.d("Geofencing ","Permission Error");
                        }

                        break;
                    case "driver arrived at pickup point":
                        tripStatus=2;
                        trackPreference.edit().putString("tripStatus","2").commit();
                        actionButton.setText(status[tripStatus]);
                        currentBookingViewModel.setTripStatus(""+tripStatus);
                        actionButton.setEnabled(true);
                        currentBookingViewModel.reSetStatus();
                        break;

                    case "ride started":
                        tripStatus=3;
                        trackPreference.edit().putString("tripStatus","3").commit();
                        currentBookingViewModel.setStartingLocation(new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude()));
                        actionButton.setText(status[tripStatus]);
                        currentBookingViewModel.setTripStatus(""+tripStatus);
                        pickupPoint.setText(booking.getDropLocation());
                        //actionButton.setEnabled(true);
                        enableButtonDrop=1;
                        currentBookingViewModel.reSetStatus();
                        break;
                    case "ride ended":
                        tripStatus=0;
                        currentBookingViewModel.setTripStatus(""+tripStatus);
                        stopService(new Intent(MainActivity.this,LocationService.class));
                        stopService(new Intent(MainActivity.this,FloatingHeadDialog.class));
                        Bundle bundle=new Bundle();
                        BookingCompletedFragment bookingCompletedFragment=new BookingCompletedFragment();
                        bundle.putString("booking",GsonStringConvertor.gsonToString(currentBookingViewModel.getCurrentBooking().getValue()));
                        bookingCompletedFragment.setArguments(bundle);
                        currentBookingViewModel.deleteCurrentBookingData();
                        actionButton.setEnabled(true);
                        trackPreference.edit().clear().commit();
                        currentBookingViewModel.reSetStatus();
                        getSupportFragmentManager().beginTransaction().add(R.id.map_container,bookingCompletedFragment)
                                .commit();

                }
            }
        });

        googleMapsDirectionViewModel.getDistance().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                if (s!=null){
                    Log.d("Estimate Distance",s);
                    initiatedArrived(s);
                }
            }
        });

        currentBookingViewModel.getError().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {

                if (!actionButton.isEnabled()) {
                    actionButton.setEnabled(true);
                    Snackbar.make(findViewById(android.R.id.content), s + " Check Internet Connection", Snackbar.LENGTH_LONG).show();
                }
            }
        });

        tripStatus=Integer.parseInt(currentBookingViewModel.getTripStatus().getValue());
        actionButton.setText(status[tripStatus]);
        navigationButton.setOnClickListener(this);
        actionButton.setOnClickListener(this);
        userNames.setOnClickListener(this);
        checkPermission();

    }

    private GeofencingRequest getGeofencingRequest() {
        GeofencingRequest.Builder builder = new GeofencingRequest.Builder();
        builder.setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER);
        builder.addGeofences(geofenceList);
        return builder.build();
    }

    private PendingIntent getGeofencePendingIntent() {
        // Reuse the PendingIntent if we already have it.
        if (mGeofencePendingIntent != null) {
            return mGeofencePendingIntent;
        }
        Intent intent = new Intent(this, GeofenceTransitionsIntentService.class);
        // We use FLAG_UPDATE_CURRENT so that we get the same pending intent back when
        // calling addGeofences() and removeGeofences().
        mGeofencePendingIntent = PendingIntent.getService(this, 0, intent, PendingIntent.
                FLAG_UPDATE_CURRENT);
        return mGeofencePendingIntent;
    }



    public void setPolyLine(String polyLine){
        mMap.addPolyline(new PolylineOptions().addAll(PolyUtil.decode(polyLine)));
        List<LatLng> latLngList=PolyUtil.decode(polyLine);
        pickUpCityLatLng=latLngList.get(0);
        dropCityLatLng=latLngList.get(latLngList.size()-1);
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        builder.include(pickUpCityLatLng);
        builder.include(dropCityLatLng);
        CameraUpdate cameraUpdate=CameraUpdateFactory.newLatLngBounds(builder.build(),150);
        mMap.animateCamera(cameraUpdate);
        pickUpMarker.setPosition(pickUpCityLatLng);
        dropMarker.setPosition(dropCityLatLng);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap=googleMap;
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(28.596501, 76.990833),12));
        if (tripStatus<=2) {
            Intent pickUpIntent = new Intent(this, FetchLocationIntentService.class);
            pickUpIntent.putExtra("resultCode", "511");
            pickUpIntent.putExtra("receiver", locationFromGeoCoderReceiver);
            pickUpIntent.putExtra("location", booking.getPickupLocation());
            startService(pickUpIntent);
        }if (tripStatus>=3 && booking.getDropLocation()!=null && booking.getDropLocation().length()>0){
            Intent dropIntent = new Intent(this, FetchLocationIntentService.class);
            dropIntent.putExtra("resultCode", "512");
            dropIntent.putExtra("receiver", locationFromGeoCoderReceiver);
            if (booking.getDropLocation()!=null && booking.getDropLocation().length()>0) {
                dropIntent.putExtra("location", booking.getDropLocation());
            }
            startService(dropIntent);
        }

        if (currentLocation!=null) {
            if (currentMarker == null) {
                currentMarker = mMap.addMarker(new MarkerOptions()
                        .icon(BitmapDescriptorFactory.fromResource(R.mipmap.taxi_dark_128))
                        .position(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude())));
            } else {
                currentMarker.setPosition(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()));
            }

            currentMarker.setRotation(currentLocation.getBearing());
            if (eta!=null) {
                currentMarker.setTitle(eta);
                currentMarker.showInfoWindow();
            }
        }
        else {
            Log.d("Current Location","Unavailable");
        }

    }

    @Override
    public void onClick(View view) {
        Log.d("View",""+view.getId());

        switch (view.getId()){
            case R.id.startNavigationButton:
                if (pickupPoint.getText().toString().length()>1) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (Settings.canDrawOverlays(MainActivity.this)){
                            Uri gmmIntentUri = Uri.parse("google.navigation:q=+" + pickupPoint.getText().toString() + "&mode=d\"");
                            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                            mapIntent.setPackage("com.google.android.apps.maps");
                            startActivity(mapIntent);
                            Intent intent=new Intent(MainActivity.this,FloatingHeadDialog.class);
                            SharedPreferences dialogPref=getSharedPreferences("dialogPref",MODE_PRIVATE);
                            dialogPref.edit().putString("bookingInfo",GsonStringConvertor.gsonToString(booking)).commit();
                            startService(intent);
                        }
                        else {
                            startActivityForResult( new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())),REQUEST_OVERLAY_SETTING);
                        }
                    }
                    else {
                        Uri gmmIntentUri = Uri.parse("google.navigation:q=+" + pickupPoint.getText().toString() + "&mode=d\"");
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);
                        Intent intent=new Intent(MainActivity.this,FloatingHeadDialog.class);
                        intent.putExtra("bookingInfo",GsonStringConvertor.gsonToString(booking));
                        startService(intent);
                    }
                }else {
                    Toast.makeText(MainActivity.this,"Address Unavailable",Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.tripActionButton:
                if (NetworkStatus.isInternetConnected(getApplication())) {
                    Log.d("Trip Status",""+tripStatus);
                    switch (tripStatus) {

                        case 0: if (currentLocation!=null && !journeyStartedFromGarageDialog.isAdded()) {
                                journeyStartedFromGarageDialog.show(getSupportFragmentManager(),"start from garage");
                            }
                            else {
                            Snackbar.make(findViewById(android.R.id.content),"Location Unavailable",Snackbar.LENGTH_SHORT).show();
                        }
                            break;
                        case 1:
                            if (!hasEnteredPickupGeoFence){
                                Toast.makeText(MainActivity.this,"You are not within 500m range of Pickup Location",Toast.LENGTH_LONG).show();
                            }
                            actionButton.setEnabled(false);
                                if (currentBookingViewModel.getGarageLocation()!=null) {
                                    googleMapsDirectionViewModel.getEstimateDistanceTime(currentBookingViewModel.getGarageLocation(),
                                            currentMarker.getPosition(), getResources().getString(R.string.distance_matrix_key));
                                    Log.d("garageLocation","Not Null");
                                }
                                else {
                                    Log.d("garageLocation","Null");
                                }
                            break;
                        case 2:
                                if (!startJourneyDialog.isAdded()) {
                                    startJourneyDialog.show(getSupportFragmentManager(), "Start Dialog");
                                }
                                break;
                        case 3:
                            googleMapsDirectionViewModel.getEndEstimateDistanceTime(new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude()),
                                currentBookingViewModel.getStartingLoction(),currentBookingViewModel.getGarageLocation(),getResources().getString(R.string.distance_matrix_key));
                            try {
                                Polyline polyline = mMap.addPolyline(new PolylineOptions().addAll(PolyUtil.decode(currentBookingViewModel.getPolyLine())).width(2).color(Color.BLACK));
                                Log.d("PolyLine", currentBookingViewModel.getPolyLine() + " s");
                            }catch (Exception e){
                                Log.e("Polyline","Not available");
                            }
                            //endJourneyDialog.show(getSupportFragmentManager(),"End Dialog");
                            break;

                    }
                    //StartJourneyDialog startJourneyDialog = new StartJourneyDialog();
                    //startJourneyDialog.show(getSupportFragmentManager(), "Start Dialog");
                }
                else {
                    Snackbar.make(view,"Internet Connection Unavailable",Snackbar.LENGTH_SHORT).show();
                }
                break;
            case R.id.location:
                //currentBookingViewModel.deleteCurrentBookingData();
                //trackPreference.edit().clear().commit();
                break;
            case R.id.userName:
                Log.d("User","Clicked");
                //currentBookingViewModel.deleteCurrentBookingData();
                PhoneBottomSheet phoneBottomSheet=new PhoneBottomSheet();
                Bundle args=new Bundle();
                args.putString("bookingInfo",GsonStringConvertor.gsonToString(booking));
                phoneBottomSheet.setArguments(args);
                phoneBottomSheet.show(getSupportFragmentManager(),"phoneBottomSheet");
                //bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                //startService(new Intent(this, LocationService.class));
                break;
         /*   case R.id.pause_resume:
                Intent intent=new Intent(this,LocationService.class);
                if (currentBookingViewModel.getIsPaused()){
                    // currentBookingViewModel.setIsPaused(false);
                    intent.putExtra("pause",false);
                    pauseResumeButton.setText("Pause Trip");
                    actionButton.setVisibility(View.VISIBLE);
                }
                else {
                    // currentBookingViewModel.setIsPaused(true);
                    intent.putExtra("pause",true);
                    pauseResumeButton.setText("Resume Trip");
                    actionButton.setVisibility(View.GONE);
                }
                Log.d("IsPaused",currentBookingViewModel.getIsPaused()+"");
                startService(intent);

                */
        }
    }

    void initiatedArrived(String distance){
        currentBookingViewModel.initiateDriverArrived(driverInfoViewModel.getAccessToken().getValue()
                ,booking.getBookingId()
                ,distance
                ,Double.toString(measuredDistance));
    }

    void plotLocation(LatLng latLng,String type) {
        if (latLng == null) {
            return;
        }
        if (type.equals("pickup")) {
            pickUpMarker = mMap.addMarker(new MarkerOptions()
                    .title(booking.getPickupLocation())
                    .position(latLng));
            pickUpMarker.showInfoWindow();
        } else if (type.equals("drop")) {
            dropMarker = mMap.addMarker(new MarkerOptions()
                    .title(booking.getDropLocation())
                    .position(latLng));
            // dropMarker.showInfoWindow();
        }
        if (currentLocation != null) {
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(latLng);
            builder.include(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()));
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(builder.build(), 300);
            mMap.animateCamera(cameraUpdate, new GoogleMap.CancelableCallback() {
                @Override
                public void onFinish() {
                    Log.d("Maps Animation", "Finished");
                    if (enableButton == 0 && currentLocation != null) {
                        Log.d("CurrentLocation", "Available" + GsonStringConvertor.gsonToString(currentLocation));
                        enableButton = 1;
                        actionButton.setEnabled(true);
                    }
                    if (enableButtonDrop==1){
                        enableButtonDrop=0;
                        actionButton.setEnabled(true);
                    }

                }

                @Override
                public void onCancel() {
                    if (enableButton == 0 && currentLocation != null) {
                        Log.d("CurrentLocation", "Available");
                        enableButton = 1;
                        actionButton.setEnabled(true);
                    }
                    if (enableButtonDrop==1){
                        enableButtonDrop=0;
                        actionButton.setEnabled(true);
                    }

                }
            });
    }
    else{
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,12));
        }


   /*     if (pickUpCityLatLng!=null && dropCityLatLng!=null){
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(pickUpCityLatLng);
            builder.include(dropCityLatLng);
      //      googleMapsDirectionViewModel.getDirection(pickUpCityLatLng,dropCityLatLng,getResources().getString(R.string.direction_key));
      //      googleMapsDirectionViewModel.getEndEstimateDistanceTime(pickUpCityLatLng,dropCityLatLng,getResources().getString(R.string.distance_matrix_key));
            CameraUpdate cameraUpdate=CameraUpdateFactory.newLatLngBounds(builder.build(),150);
            mMap.animateCamera(cameraUpdate);
        }
        */

    }

    @Override
    public void onLocationChangedFromService(Location location) {
        currentLocation=location;
        LatLng latLng=new LatLng(location.getLatitude(),location.getLongitude());
        if (mMap==null){
            return;
        }
        if (currentMarker==null){
            currentMarker=mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.taxi_dark_128))
                    .position(latLng));
        }
        else {
            currentMarker.setPosition(latLng);
        }
        if (eta!=null) {
            currentMarker.setTitle(eta);
        }
        currentMarker.setRotation(location.getBearing());
        currentMarker.showInfoWindow();
       // currentMarker.setRotation(currentLocation.);
        if (tripStatus<3 && pickUpMarker!=null && pickUpMarker.getPosition()!=null) {
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(latLng);
            builder.include(pickUpMarker.getPosition());
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(builder.build(), 300);
            mMap.moveCamera(cameraUpdate);
            Log.d("ServiceBound","true");
        }
        else if (tripStatus>=3 && dropMarker!=null && dropMarker.getPosition()!=null) {
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(latLng);
            builder.include(dropMarker.getPosition());
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(builder.build(), 300);
            mMap.animateCamera(cameraUpdate, new GoogleMap.CancelableCallback() {
                @Override
                public void onFinish() {
                    if (enableButtonDrop==1){
                        enableButtonDrop=0;
                        actionButton.setEnabled(true);
                    }
                }

                @Override
                public void onCancel() {
                    if (enableButtonDrop==1){
                        enableButtonDrop=0;
                        actionButton.setEnabled(true);
                    }
                }
            });
            Log.d("ServiceBound","true");
        }
        else {
            Log.d("ServiceBound","false");
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16));
        }

        if (enableButton==0 && currentLocation!=null){
            Log.d("CurrentLocation","Available");
            enableButton=1;
            actionButton.setEnabled(true);
        }
       /* if (dropCityLatLng!=null) {
        }
        */

    }

    @Override
    public void onETAchanged(String s) {
        if (tripStatus>=3 && (booking.getDropLocation()==null|| booking.getDropLocation().length()<1)){
            eta=null;
            return;
        }
        eta=s;
        if (currentMarker!=null) {
            currentMarker.setTitle(s);
            currentMarker.showInfoWindow();
        }
    }

    @Override
    public void onDistanceChanged(Double distance) {
        userNames.setText("Distance Travelled : "+distance);
        if (distance!=null) {
            measuredDistance = distance;
        }
    }

    @Override
    public void onPathLatLngChanged(ArrayList<LatLng> pathLatLng) {
        this.pathLatLng=pathLatLng;
       // mMap.addPolyline(new PolylineOptions().addAll(pathLatLng));
    }

    @Override
    public void onStartRideClicked(String startkm) {
        Log.d("StartKm",startkm);
        actionButton.setEnabled(false);
        currentBookingViewModel.initiateRideStarted(
                driverInfoViewModel.getAccessToken().getValue(),
                booking.getBookingId(),
                booking.getPickupLocation(),
                startkm
                );
    }

    @Override
    public void onRideEnd(String endKm, String stateTax, String parking, String tollTax,String otherTax,String garageDistance
    ,String estimateGarageDistance,String estimateTimeToReachGarage,String calculatedTripDistance) {
        actionButton.setEnabled(false);
        currentBookingViewModel.initiateEndRide(driverInfoViewModel.getAccessToken().getValue(),booking.getBookingId(),
                booking.getDropLocation(),garageDistance,endKm,stateTax,parking,tollTax,otherTax,Double.toString(measuredDistance),
                estimateGarageDistance,estimateTimeToReachGarage,calculatedTripDistance);
    }


    @Override
    public void onStartFromGarageClicked(String startKm) {
        Log.d("StartKm",startKm);
        actionButton.setEnabled(false);
        garageLocation = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        currentBookingViewModel.initiateDriverStarted(driverInfoViewModel.getAccessToken().getValue(),
                booking.getBookingId(), GsonStringConvertor.gsonToString(currentLocation),startKm);
    }


    /**
     * ReceiverClass to get lat-lng from address/placeName from FetchLocationIntentService
     */
    class LocationFromGeoCoderReceiver extends ResultReceiver{

        public LocationFromGeoCoderReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) { //resultData bundle received from FetchLocationIntentService

            Log.d("ResultCode", "" + resultCode+" "+GsonStringConvertor.gsonToString(resultData));
            switch (resultCode) {
                case 511:
                    if (resultCode == 511 && resultData.getBoolean("isSuccessful")) {
                        pickUpCityLatLng = new LatLng(Double.parseDouble(resultData.getString("lat")),
                                Double.parseDouble(resultData.getString("lng")));
                        //save latlng of pickup location.
                        //it is used to calculate ETA.so it is saved as dropLocation for using it use as drop location untill driver reaches pickup location.
                        trackPreference.edit().putString("dropLocation",resultData.getString("lat")+","+resultData.getString("lng"))
                                .commit();

                        plotLocation(pickUpCityLatLng,"pickup");
                    }
                    else {
                        Log.e("Error",resultData.getString("error"));
                    }
                    break;
                case 512:
                    if (resultCode == 512 && resultData.getBoolean("isSuccessful")) {
                        dropCityLatLng = new LatLng(Double.parseDouble(resultData.getString("lat")),
                                Double.parseDouble(resultData.getString("lng")));
                        //save latlng of drop location.
                        //it is used to calculate ETA.so it is saved as dropLocation for using it use as drop location untill driver reaches pickup location.
                        trackPreference.edit().putString("dropLocation",resultData.getString("lat")+","+resultData.getString("lng"))
                                .commit();
                        plotLocation(dropCityLatLng,"drop");

                    }
                    else {
                        Log.e("Error",resultData.getString("error"));
                    }
                    break;
            }
        }

    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        LocationChangeClass.removeLocationChangeListener(this); //Remove LocationChangedListener to avoid data leak when activity is destroyed.
    }

    /**
     * Function to check location permission.
     */
    void checkPermission(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_FINE_LOCATION)){
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Permissions Required For Tracking ");
                builder.setMessage("location details are required to track and find Estimate time of arrival");
                builder.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d("Permission Request", " Accepted");
                        ActivityCompat.requestPermissions(MainActivity.this,permissions, PERMISSION_CODE);
                    }
                });
                builder.setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d("Permission Request", "Denied");
                    }
                });
                builder.show();
            }
            else {
                ActivityCompat.requestPermissions(this,permissions, PERMISSION_CODE);
            }
        }
        else {
            Log.d("Permission","Available");
            startTracking(); //permission available start tracking.
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case PERMISSION_CODE:
                Log.d("Permission","Both "+ GsonStringConvertor.gsonToString(permissions)+" "+ GsonStringConvertor.gsonToString(grantResults));
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startTracking();
                } else {
                /*  Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    this.startActivity(intent);
                    */
                }
                return;
        }
    }

    /**
     * Function to start tracking.
     */
    void startTracking(){
        buildGoogleApiClient();
        mGoogleApiClient.connect();
    }

    /**
     * Function to Create GoogleApiClient to access location service.
     */
    private synchronized void buildGoogleApiClient() {
        Log.e("build", "build1");
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .enableAutoManage(this,this)
                .addApi(LocationServices.API)
                .build();
        Log.e("build", "build2");
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.d("Google Api","Connected");
        buildLocationSettingsRequest(); //on googleapiconnected create LocationSettingRequest object
        checkLocationSettings(); //Check location Services.

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    /**
     * Function to Create Location setting object.
     * @return created LocationRequest object
     */
    protected LocationRequest createLocationRequest() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(2000); //very small time for real time location plotting
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setSmallestDisplacement(10);//to remove unnecessary location updates when vehicle is stationary
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);// high priority to get accurate location.
        return mLocationRequest;
    }

    /**
     * Function to build Location Setting Request.
     * it creates LocationSettingRequest object which is used to check Location Settings.
     */
    protected void buildLocationSettingsRequest() {
        Log.e("buildlocation", "build1");
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(createLocationRequest()).setAlwaysShow(true);
        mLocationSettingsRequest = builder.build();
        Log.e("buildlocation", "build2");
    }

    /**
     * Function to check Location Settings.
     * set result callbacks for accessing response.
     */
    protected void checkLocationSettings() {
        Log.e("buildcheck", "build1");
        PendingResult<LocationSettingsResult> result = LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient, mLocationSettingsRequest);
        result.setResultCallback(this); //set callbacks to get response.
        Log.e("buildcheck", "build1");
    }

    @Override
    public void onResult(@NonNull LocationSettingsResult locationSettingsResult) {
        final Status status = locationSettingsResult.getStatus();

        switch (status.getStatusCode()) {
            case LocationSettingsStatusCodes.SUCCESS: //gps is enabled start location updates
                Log.i("TAG", "All location settings are satisfied.");
                startLocationUpdates();
                break;
            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED: //gps is closed show the dialog to enable the gps in screen.
                Log.i("TAG", "Location settings are not satisfied. Show the user a dialog to" +
                        "upgrade location settings ");
                try {
                    status.startResolutionForResult(MainActivity.this, REQUEST_CHECK_SETTINGS);
                } catch (IntentSender.SendIntentException e) {
                    Log.i("TAG", "PendingIntent unable to execute request.");

                }
                break;
            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE://gps of device cannot be used by the app. kill the activity
                Log.i("TAG", "Location settings are inadequate, and cannot be fixed here. Dialog " +
                        "not created.");
                finish();
                break;
        }
    }

    @Override
    public void onActivityResult(int reqCode, int resultCode, Intent data){
        switch (reqCode){
            case REQUEST_CHECK_SETTINGS: //Location Setting response
                switch (resultCode) {
                    case Activity.RESULT_OK:  //start location updates
                        startLocationUpdates();
                        break;
                    case Activity.RESULT_CANCELED: // finish the activity because driver is not allowed to use this section without enabling location
                        // The user was asked to change settings, but chose not to
                        Log.e("result", "cancelled");
                        Toast.makeText(MainActivity.this,"Please Enable Location To Continue",Toast.LENGTH_LONG).show();
                        finish();
                        break;
                    default:
                        break;
                }
                break;
            case REQUEST_OVERLAY_SETTING:// Overlay Permission to show an icon on the screen to return back to app
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(MainActivity.this)){ //Create screen overlay and start navigation to the desired location
                        Uri gmmIntentUri = Uri.parse("google.navigation:q=+" + pickupPoint.getText().toString() + "&mode=d\"");
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);
                        Intent intent=new Intent(MainActivity.this,FloatingHeadDialog.class);
                        intent.putExtra("bookingInfo",GsonStringConvertor.gsonToString(booking));
                        startService(intent);
                    }else {// Don't create overlay just start navigation on google maps
                        Uri gmmIntentUri = Uri.parse("google.navigation:q=+" + pickupPoint.getText().toString() + "&mode=d\"");
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);
                    }
                }
                // for versions older then Android M.
                Uri gmmIntentUri = Uri.parse("google.navigation:q=+" + pickupPoint.getText().toString() + "&mode=d\"");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
                break;

        }
    }


    /**
     *Function to start location update for the current location of taxi.
     * it checks for the permission
     * if there is any current booking then LocationService is already running so disconnect mGoogleApiClient to save battery
     * if not a current booking then start location update
     */
    protected void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        else if (currentBookingViewModel.getIsCurrentBooking()){
            mGoogleApiClient.disconnect();
            return;
        }
        //start location updates.
        com.google.android.gms.location.LocationServices.FusedLocationApi.requestLocationUpdates(
                mGoogleApiClient, createLocationRequest(), MainActivity.this);
    }

    /**
     * Function to stop Location updates
     */
    protected void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(
                mGoogleApiClient, this);
    }

    /**
     * Function to get current location updates
     * @param location : current location of taxi
     * Both vehicle and destination are shown by using Latlng bounds.
     */
    @Override
    public void onLocationChanged(Location location) {
        LatLng latLng=new LatLng(location.getLatitude(),location.getLongitude());
        currentLocation=location;
        Log.d("CurrentLocation",GsonStringConvertor.gsonToString(location));
        if (mMap==null){                            //check if map is ready
            return;
        }
        if (currentBookingViewModel.getIsCurrentBooking()){  // If current booking then
            stopLocationUpdates();                           // stop location update and disconnect googleApiClient to save battery
            mGoogleApiClient.disconnect();
        }
        if (currentMarker==null){ //create new marker and set its location
            currentMarker=mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.taxi_dark_128))
                    .position(latLng));
        }
        else { // update marker position
            currentMarker.setPosition(latLng);
        }

        //rotation to move taxi in the direction of motion of vehicle.
        currentMarker.setRotation(location.getBearing());

       if (tripStatus<3 &&pickUpMarker!=null && pickUpMarker.getPosition()!=null) {
           Log.d("ServiceBound","true");
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(latLng);
           builder.include(pickUpMarker.getPosition());
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(builder.build(),300);
            mMap.animateCamera(cameraUpdate, new GoogleMap.CancelableCallback() {
                @Override
                public void onFinish() {
                    Log.d("Maps Animation","Finished");
                    if (enableButton==0 && currentLocation!=null){
                        Log.d("CurrentLocation","Available");
                        enableButton=1;                 //
                        actionButton.setEnabled(true);  //action button enabled after latlngs are animated.
                    }

                }

                @Override
                public void onCancel() {

                }
            });
        }
        else {
           Log.d("ServiceBound","false");
       }

        /* else {
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16), 5000, new GoogleMap.CancelableCallback() {
                @Override
                public void onFinish() {
                    Log.d("Status","Finished");
                }

                @Override
                public void onCancel() {
                    Log.d("Status","Cancel");
                }
            });
       // }
       */
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
