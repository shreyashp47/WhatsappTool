package com.taxivaxi.driver.tracking;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.taxivaxi.driver.R;
import com.taxivaxi.driver.activities.MainActivity;
import com.taxivaxi.driver.eventlistener.eventclass.LocationChangeClass;
import com.taxivaxi.driver.models.googledistancematrix.DistanceMatrixApiResponse;
import com.taxivaxi.driver.models.login.Driver;
import com.taxivaxi.driver.models.registerfcm.RegisterFirebaseDatabaseResponse;
import com.taxivaxi.driver.models.tracking.FirebaseTrackingModel;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.repository.CurrentBookingRepository;
import com.taxivaxi.driver.retrofit.AddFirebaseDatabasekey;
import com.taxivaxi.driver.retrofit.ConfigRetrofit;
import com.taxivaxi.driver.retrofit.GoogleAPI;
import com.taxivaxi.driver.utility.GsonStringConvertor;
import com.taxivaxi.driver.utility.NetworkStatus;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by sandeep on 13/9/17.
 */

public class LocationService extends Service implements GoogleApiClient.OnConnectionFailedListener,GoogleApiClient.ConnectionCallbacks,
        com.google.android.gms.location.LocationListener,SharedPreferences.OnSharedPreferenceChangeListener{

    SharedPreferences trackingSharedPreference,loginInfo;
    GoogleApiClient mGoogleApiClient;
    private static final String TAG="LocationService";
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private LocationCallback mLocationCallback;
    private FusedLocationProviderClient mFusedLocationClient;
    String key;
    Booking booking;
    //SendTrckingLinkAPI sendTrckingLinkAPI;
    Date date;
    String senderId;
    FirebaseApp trackingApp;
    GoogleAPI googleApi;
    Location currentLocation;
    String eta;
    int etaCalled=0;
    String tripStatus="1";
    Boolean paused=false;
    CurrentBookingRepository  currentBookingRepository;

    ArrayList<LatLng> pathLatLng;

    double distanceTravelled=0;
    int i=0;

    Timer timer=new Timer();

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG,"Inside OnCreate");
        pathLatLng=new ArrayList<>();
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(com.google.android.gms.location.LocationServices.API)
                    .build();
        }

        mGoogleApiClient.connect();
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApplicationId("1:846362637861:android:dfcf6a4ea1b68e1e") // Required for Analytics.
                .setApiKey("AIzaSyBgXCStOyBQsA7RiaP-r8bh5b01Xnvs-Vk") // Required for Auth.
                .setDatabaseUrl("https://taxivaxi-tracking-project.firebaseio.com/") // Required for RTDB.
                .build();
        //sendTrckingLinkAPI= ConfigRetrofit.configRetrofit(SendTrckingLinkAPI.class);
        trackingSharedPreference =getSharedPreferences("trackingPref",MODE_PRIVATE);
        loginInfo=getSharedPreferences("driverPref",MODE_PRIVATE);

        trackingSharedPreference.registerOnSharedPreferenceChangeListener(this);

        distanceTravelled=Double.parseDouble(trackingSharedPreference.getString("distanceTravelled","0"));

        googleApi= ConfigRetrofit.configGoogleRetrofit(GoogleAPI.class);

        senderId= GsonStringConvertor.stringToGson(loginInfo.getString("driverInfo","n"),Driver.class).getId();
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        List<FirebaseApp> firebaseAppList=FirebaseApp.getApps(this);
        boolean flag=false;
        for (int i=0;i<firebaseAppList.size();i++){
            Log.d("FirebaseAppName",firebaseAppList.get(i).getName());
            if (firebaseAppList.get(i).getName().equals("tracking")){
                trackingApp = FirebaseApp.getInstance("tracking");
                flag=true;
                break;
            }
        }
        if (!flag){
            FirebaseApp.initializeApp(this /* Context */, options, "tracking");
        }
        trackingApp = FirebaseApp.getInstance("tracking");
        firebaseDatabase=FirebaseDatabase.getInstance(trackingApp);
        databaseReference=firebaseDatabase.getReference("corporate").child("spoc");
        if (!trackingSharedPreference.getBoolean("isUserRegistered",false)){
            key=databaseReference.push().getKey();
            SharedPreferences.Editor editor=trackingSharedPreference.edit();
            editor.putBoolean("isUserRegistered",true);
            editor.putString("key",key);
            editor.commit();
            AddFirebaseDatabasekey addFirebaseDatabasekey = ConfigRetrofit.configRetrofit(AddFirebaseDatabasekey.class);
            addFirebaseDatabasekey.addFirebaseKey(loginInfo.getString("accessToken", "n"), trackingSharedPreference.getString("bookingId", "n"), key).enqueue(new Callback<RegisterFirebaseDatabaseResponse>() {
                @Override
                public void onResponse(Call<RegisterFirebaseDatabaseResponse> call, Response<RegisterFirebaseDatabaseResponse> response) {
                    if (response.isSuccessful() && response.body().getSuccess().equals("1")) {
                        Log.d("Database Registered", "True");
                    }
                }

                @Override
                public void onFailure(Call<RegisterFirebaseDatabaseResponse> call, Throwable t) {

                }
            });
        }
        else {
            key=trackingSharedPreference.getString("key","n");
        }

        currentBookingRepository=CurrentBookingRepository.getInstance(getApplication());
        tripStatus=trackingSharedPreference.getString("tripStatus","1");
        booking=GsonStringConvertor.stringToGson(trackingSharedPreference.getString("bookingInfo","n"),Booking.class);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        databaseReference=firebaseDatabase.getReference("corporate").child("driver").child(trackingSharedPreference.getString("bookingId","n")).child(key);
        scheduleEOT();
    }

    @Override
    public int onStartCommand(Intent intent,int flags, int startId) {
        Log.d(TAG,"Inside OnStartCommand");
            Log.d(TAG,"Inside OnSendTrack");

            if (intent.getBooleanExtra("pause",false)){
                trackingSharedPreference.edit().putBoolean("isPaused",true)
                        .putString("distanceTravelled",Double.toString(distanceTravelled)).commit();
                stopSelf();
            }
            else {
                trackingSharedPreference.edit().putBoolean("isPaused",false).commit();
            }

            Intent intent1 = new Intent(this, MainActivity.class);
            intent1.putExtra("fromNotification",true);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent1, 0);

            Notification notification = new Notification.Builder(this)
                    .setContentTitle("Tracking Enabled")
                    .setContentText("You are moving to drop Employee")
                    .setSmallIcon(R.drawable.tv_app_status_logo_192)
                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.tv_app_status_logo_192))
                    .setContentIntent(pendingIntent)
                    .build();
            startForeground(1001, notification);

        return START_STICKY;
    }

    protected LocationRequest createLocationRequest() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(5000);
        mLocationRequest.setFastestInterval(3000);
        mLocationRequest.setSmallestDisplacement(15);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return mLocationRequest;
    }

    protected void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        com.google.android.gms.location.LocationServices.FusedLocationApi.requestLocationUpdates(
                mGoogleApiClient, createLocationRequest(), LocationService.this);
    }

    protected void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(
                mGoogleApiClient, this);
    }

    @Override
    public void onDestroy() {
        Log.d(TAG,"Destoryed");
        stopLocationUpdates();
        mGoogleApiClient.disconnect();
        timer.cancel();
        if (!trackingSharedPreference.getBoolean("isPaused",false)) {
            databaseReference.setValue(null);
        }
        trackingSharedPreference.unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        startLocationUpdates();

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        if(location.getAccuracy()>50){
            return;
        }
        if (currentLocation!=null) {
            distanceTravelled = distanceTravelled + currentLocation.distanceTo(location);
        }
        currentLocation=location;
        LocationChangeClass.onLocationChanged(location);
        LocationChangeClass.onDistanceChanged(distanceTravelled);
        if (etaCalled==0){
            etaCalled=1;
            getEOT();
        }
        if (NetworkStatus.isInternetConnected(getApplication())) {
            databaseReference.setValue(new FirebaseTrackingModel(senderId,
                    Double.toString(location.getLatitude()),
                    Double.toString(location.getLongitude()),
                    eta,
                    Double.toString(currentLocation.getBearing()),
                    tripStatus));
            Log.i("Status","Internet Connection"+ GsonStringConvertor.gsonToString(location));
        }
        else {
            Log.i("Status","No Internet Connection");
        }
    }

    void scheduleEOT(){
        timer.scheduleAtFixedRate(
                new TimerTask() {
            @Override
            public void run() {
                getEOT();
            }
        },4000,100000);
    }

    void getEOT(){
        if (currentLocation==null){
            Log.d("Current Location","null");
            return;
        }
       /* if (i==0){
            pathLatLng.add(new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude()));
            LocationChangeClass.onPathLatLngChanged(pathLatLng);
            i=5;
        }
        else {
            i--;
        }*/
       currentBookingRepository.setPolyLine(currentLocation);
        if (tripStatus.equals("3")&&booking.getTourType().equals("Local")){
            eta="Drop Location Unavailable";
            Log.d("TripType1",booking.getTourType()+" "+tripStatus);
            LocationChangeClass.onETAChanged(eta);
        }
        else {
            Log.d("TripType2",booking.getTourType()+" "+tripStatus);
            String pickUp = currentLocation.getLatitude() + "," + currentLocation.getLongitude();
            String drop = trackingSharedPreference.getString("dropLocation", "n");
            googleApi.getEstimateDistanceAndTime(pickUp, drop, "now", "best_guess", getResources().getString(R.string.distance_matrix_key)).enqueue(
                    new Callback<DistanceMatrixApiResponse>() {
                        @Override
                        public void onResponse(Call<DistanceMatrixApiResponse> call, Response<DistanceMatrixApiResponse> response) {
                            if (response.isSuccessful() && response.body().getStatus().equals("OK") && response.body().getRows().get(0).getElements() != null) {
                                eta = response.body().getRows().get(0).getElements().get(0).getDurationInTraffic().getText();
                                LocationChangeClass.onETAChanged(eta);
                                Log.d("EAT", eta);
                                if (NetworkStatus.isInternetConnected(getApplication())) {
                                    FirebaseTrackingModel firebaseTrackingModel = new FirebaseTrackingModel(senderId,
                                            Double.toString(currentLocation.getLatitude()),
                                            Double.toString(currentLocation.getLongitude()),
                                            eta,
                                            Double.toString(currentLocation.getBearing()),
                                            tripStatus);
                                    databaseReference.setValue(firebaseTrackingModel);
                                    Log.i("Status", "Internet Connection" + GsonStringConvertor.gsonToString(currentLocation));
                                }
                            }
                        }

                        @Override
                        public void onFailure(Call<DistanceMatrixApiResponse> call, Throwable t) {

                        }
                    }
            );
        }

    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        Log.d("LocationService",s);
        switch (s){
            case "dropLocation":
                if (booking.getTourType().equals("Local") && tripStatus.equals("3")) {
                    Log.d("TripType3",booking.getTourType()+" "+tripStatus);
                    eta="Drop Location Unavailable";
                    LocationChangeClass.onETAChanged(eta);
                }
                else {
                    Log.d("TripType4",booking.getTourType()+" "+tripStatus);
                    getEOT();
                }
                break;
            case "tripStatus": tripStatus=trackingSharedPreference.getString(s,"0");
            if (tripStatus.equals("3")&&booking.getTourType().equals("Local")) {
                eta="Drop Location Unavailable";
                LocationChangeClass.onETAChanged(eta);
                Log.d("TripType5",booking.getTourType()+" "+tripStatus);
            }
            else {
                Log.d("TripType6",booking.getTourType()+" "+tripStatus);
                getEOT();
            }
            break;
        }

    }

}
