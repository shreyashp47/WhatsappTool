package com.taxivaxi.driver.activities;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.fragment.EnterLoginDetailsFragment;
import com.taxivaxi.driver.viewmodels.DriverInfoViewModel;

public class LoginActivity extends AppCompatActivity {
    FrameLayout frameLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        frameLayout=(FrameLayout)findViewById(R.id.container_login_details);
        Fragment enterLoginDetailsFragment=new EnterLoginDetailsFragment();

        DriverInfoViewModel employeeViewModel= ViewModelProviders.of(this).get(DriverInfoViewModel.class);
        if (employeeViewModel.getIsLogin()) {
            Log.d("Info","access_token "+employeeViewModel.getAccessToken().getValue()+"  "+Boolean.toString(employeeViewModel.getIsLogin()));
            startActivity(new Intent(LoginActivity.this,HomeActivity.class));
            finish();
        }else {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container_login_details,enterLoginDetailsFragment)
                    .commit();

        }

    }
}
