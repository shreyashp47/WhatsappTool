package com.taxivaxi.driver.retrofit;

import com.taxivaxi.driver.models.driverarrived.DriverArrivedApiResponse;
import com.taxivaxi.driver.models.driverstarted.DriverStartedApiResponse;
import com.taxivaxi.driver.models.endride.EndRideApiResponse;
import com.taxivaxi.driver.models.startride.StartRideApiResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by sandeep on 15/11/17.
 */

public interface DriverStartedAPI {

    @FormUrlEncoded
    @POST(ApiURLs.driverStartedURL)
    Call<DriverStartedApiResponse> triggerDriverStarted(@Field("access_token") String accessToken,
                                                        @Field("booking_id") String bookingId,
                                                        @Field("garage_location") String garageLocation,
                                                        @Field("start_km") String startKm);

    @FormUrlEncoded
    @POST(ApiURLs.driverArrived)
    Call<DriverArrivedApiResponse> initiateDriverArrived(@Field("access_token") String accessToken,
                                                         @Field("booking_id") String bookingId,
                                                         @Field("garage_distance_from_pickup") String garageDistance,
                                                             @Field("measured_garage_distance_from_pickup") String measuredGarageDistance);

    @FormUrlEncoded
    @POST(ApiURLs.rideStarted)
    Call<StartRideApiResponse> initiateStartRide(@Field("access_token") String accessToken,
                                                 @Field("booking_id") String bookingId,
                                                 @Field("start_location") String startLocation,
                                                 @Field("start_km") String startKm);

    @FormUrlEncoded
    @POST(ApiURLs.endRideURL)
    Call<EndRideApiResponse> initiateEndRide(@Field("access_token") String accessToken,
                                             @Field("booking_id") String bookingId,
                                             @Field("drop_location") String dropLocation,
                                             @Field("garage_distance_from_drop") String garageDistanceFromDrop,
                                             @Field("end_km") String endKm,
                                             @Field("state_tax") String stateTax,
                                             @Field("parking") String parking,
                                             @Field("toll_tax") String tollTax,
                                             @Field("others") String otherTax,
                                             @Field("estimated_distance") String estimatedDistance,
                                             @Field("estimated_garage_distance") String estimatedGarageDistance,
                                             @Field("estimated_garage_time") String estimateGarageTime,
                                             @Field("calculated_trip_distance") String calculateTripDistance);
}
