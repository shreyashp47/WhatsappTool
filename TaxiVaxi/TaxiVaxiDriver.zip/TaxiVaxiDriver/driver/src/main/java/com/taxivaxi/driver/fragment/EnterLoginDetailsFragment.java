package com.taxivaxi.driver.fragment;

import android.arch.lifecycle.LifecycleRegistry;
import android.arch.lifecycle.LifecycleRegistryOwner;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.viewmodels.DriverInfoViewModel;


public class EnterLoginDetailsFragment extends Fragment implements LifecycleRegistryOwner,View.OnClickListener {

    EditText loginNo;
    Button login;
    DriverInfoViewModel driverInfoViewModel;
    LifecycleRegistry lifecycleRegistry=new LifecycleRegistry(this);
    LinearLayout loginLay,verifyLay;
    ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_enter_login_details, container, false);
        progressBar=view.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        driverInfoViewModel = ViewModelProviders.of(getActivity()).get(DriverInfoViewModel.class);

        driverInfoViewModel.getLoginStatus().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                if (s.equals("successful")){
                    progressBar.setVisibility(View.GONE);
                    VerificationFragment verificationFragment=new VerificationFragment();
                    Bundle bundle =new Bundle();
                    bundle.putString("contactNo",loginNo.getText().toString());
                    verificationFragment.setArguments(bundle);
                    getActivity().getSupportFragmentManager()
                            .beginTransaction()
                            .add(R.id.container_login_details,verificationFragment)
                            .addToBackStack(null)
                            .commit();
                }
            }
        });

        driverInfoViewModel.getError().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getActivity(),s,Toast.LENGTH_SHORT).show();
            }
        });
        loginNo =view.findViewById(R.id.login_no);
        login=view.findViewById(R.id.login_btn);
        login.setOnClickListener(this);
        return view;
    }


    @Override
    public void onClick(View view) {
        int id=view.getId();
        switch (id){
            case R.id.login_btn:
                if (loginNo.getText().toString().equals("")){
                    loginNo.setError("Please Enter Contact No");
                }
                else {
                    progressBar.setVisibility(View.VISIBLE);
                    driverInfoViewModel.performLogin(loginNo.getText().toString());
                }
                break;
        }
    }

    @Override
    public LifecycleRegistry getLifecycle() {
        return lifecycleRegistry;
    }
}
