package com.taxivaxi.driver.repository;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;

import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.models.upcomingbooking.UpcomingBookingApiResponse;
import com.taxivaxi.driver.retrofit.ConfigRetrofit;
import com.taxivaxi.driver.retrofit.UpcomingBookingAPI;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by sandeep on 13/11/17.
 */

public class UpcomingBookingsRepository {

    public static UpcomingBookingsRepository INSTANCE=null;
    private MutableLiveData<List<Booking>> upcomingBookings;
    private MutableLiveData<String> error;
    private UpcomingBookingAPI upcomingBookingAPI;

    private UpcomingBookingsRepository(){
        upcomingBookings=new MutableLiveData<>();
        error=new MutableLiveData<>();
        upcomingBookingAPI= ConfigRetrofit.configRetrofit(UpcomingBookingAPI.class);
    }


    public static UpcomingBookingsRepository getInstance(){
        INSTANCE=new UpcomingBookingsRepository();
        return INSTANCE;
    }

    public static void deleteInstance(){
        INSTANCE=null;
    }


    public LiveData<List<Booking>> getUpcomingBookings() {
        return upcomingBookings;
    }

    public LiveData<String> getError() {
        return error;
    }

    public void deleteUpcomingBookingList(){
        upcomingBookings.setValue(null);
    }

    public void getUpcomingBooking(String accessToken){
        upcomingBookingAPI.getUpcomingBooking(accessToken).enqueue(new Callback<UpcomingBookingApiResponse>() {
            @Override
            public void onResponse(Call<UpcomingBookingApiResponse> call, Response<UpcomingBookingApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1")&&response.body().getResponse().getBookings()!=null){
                        upcomingBookings.postValue(response.body().getResponse().getBookings());
                    }
                    else {
                        error.postValue(response.body().getError());
                    }
                }
                else {
                    error.postValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<UpcomingBookingApiResponse> call, Throwable t) {
                error.postValue("Connection Error "+t.getMessage());
            }
        });

    }

}
