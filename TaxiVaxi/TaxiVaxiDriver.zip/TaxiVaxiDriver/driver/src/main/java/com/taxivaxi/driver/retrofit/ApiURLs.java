package com.taxivaxi.driver.retrofit;

/**
 * Created by sandeep on 4/11/17.
 */

public class ApiURLs {
    static final String liveUrl="https://corporate.taxivaxi.com/mapi/v2_1/drivers/";
    static final String testUrl="https://corporate.taxivaxi.com/testmapi/v2_1/drivers/";
    static final String baseURL=testUrl;
    static final String googleApiBaseURL="https://maps.googleapis.com/maps/api/";

    static final String loginURL="login";
    static final String upcomingBookingURL="getUpComingBookings";
    static final String driverStartedURL="driver_started";
    static final String driverArrived="arrived";
    static final String rideStarted="start_ride";
    static final String endRideURL="end_ride";
    static final String addFirebaseKey="add_firebase_key";
    static final String archivedBookingURL="getPastBookings";

    static final String updateFcmToken="updateFCMRegID";

    static final String directionApiURL="directions/json?";
    static final String distanceApiURL="distancematrix/json?";
}
