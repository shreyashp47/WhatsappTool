package com.taxivaxi.driver.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.google.android.gms.maps.model.LatLng;
import com.taxivaxi.driver.models.tracking.Location;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.repository.CurrentBookingRepository;
import com.taxivaxi.driver.utility.GsonStringConvertor;

/**
 * Created by sandeep on 14/11/17.
 */

public class CurrentBookingViewModel extends AndroidViewModel {

    CurrentBookingRepository currentBookingRepository;
    LiveData<Booking> currentBooking;
    LiveData<String> tripStatus;
    LiveData<String> status;
    LiveData<String> error;
    LiveData<Boolean> hasReachedPickupPoint;

    public CurrentBookingViewModel(@NonNull Application application) {
        super(application);
        currentBookingRepository=CurrentBookingRepository.getInstance(application);
        currentBooking=currentBookingRepository.getBooking();
        tripStatus=currentBookingRepository.getTripStatus();
        status=currentBookingRepository.getStatus();
        error=currentBookingRepository.getError();
        hasReachedPickupPoint=currentBookingRepository.getHasEnteredAtPickupPoint();
    }


    public LiveData<Boolean> getHasReachedPickupPoint() {
        return hasReachedPickupPoint;
    }

    public LiveData<Booking> getCurrentBooking() {
        return currentBooking;
    }

    public LiveData<String> getTripStatus() {
        return tripStatus;
    }

    public LiveData<String> getError() {
        return error;
    }

    public void setTripStatus(String tripStatus){
        currentBookingRepository.setTripStatus(tripStatus);
    }

    public double getStartKm(){
        return currentBookingRepository.getStartKm();
    }

    public LiveData<String> getStatus() {
        return status;
    }

    public boolean getIsCurrentBooking(){
        return currentBookingRepository.getIsCurrentBooking().getValue();
    }

    public void reSetStatus(){
        currentBookingRepository.reSetStatus();
    }

    public void setCurrentBooking(String currentBooking) {
        currentBookingRepository.setIsCurrentBooking(true);
        currentBookingRepository.setBooking(currentBooking);
    }

    public void initiateDriverStarted(String accessToken,String bookingId,String garageLocation,String startKm){
        currentBookingRepository.initiateDriver(accessToken, bookingId, garageLocation,startKm);
    }

    public void initiateDriverArrived(String accessToken,String bookingId,String garageDistance,String measuredGarageDistance){
        currentBookingRepository.initiatedArrived(accessToken, bookingId, garageDistance,measuredGarageDistance);
    }

    public void initiateRideStarted(String accessToken,String bookingId,String startLocation,String startKm){
        currentBookingRepository.initiateStartRide(accessToken, bookingId, startLocation,startKm);
    }

    public void initiateEndRide(String accessToken,String bookingId,String dropLocation,String garageDistanceFromDrop,String endKm,String staTax,String parking,
                                String tollTax,String otherTax,String estimatedDistance,String estimateGarageDistance,String estimateTimeToReachGarage,
                                String calculatedTripDistance){
        currentBookingRepository.initiateEndRide(accessToken, bookingId, dropLocation, garageDistanceFromDrop, endKm, staTax, parking,tollTax, otherTax,
                estimatedDistance,estimateGarageDistance,estimateTimeToReachGarage,calculatedTripDistance);
    }

    public void deleteCurrentBookingData(){
        currentBookingRepository.deleteData();
    }

    public LatLng getGarageLocation(){
       return currentBookingRepository.getGarageLocation();
    }

    public void setGarageLocation(LatLng garageLocation){
        currentBookingRepository.setGarageLocation(garageLocation);
    }

    public boolean isStartOtpVerified(String startOtp){
        if (startOtp.equals(currentBookingRepository.getStartOtp())){
            return true;
        }else {
            return false;
        }
    }

    public boolean isEndOtpVerified(String endOtp){
        if (endOtp.equals(currentBookingRepository.getEndOtp())){
            return true;
        }else {
            return false;
        }
    }

    public LatLng getStartingLoction(){
        return currentBookingRepository.getStartingLocation();
    }

    public void setStartingLocation(LatLng startingLocation){
        currentBookingRepository.setStartingLocation(startingLocation);
    }

    public void setIsPaused(boolean isPaused){
        currentBookingRepository.setPaused(isPaused);
    }

    public boolean getIsPaused(){
        return currentBookingRepository.getPaused();
    }

    public String getPolyLine(){
        return currentBookingRepository.getPolyLine();
    }

}
