package com.taxivaxi.driver.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.taxivaxi.driver.models.login.Driver;
import com.taxivaxi.driver.repository.LoginRepository;

/**
 * Created by sandeep on 4/11/17.
 */

public class DriverInfoViewModel extends AndroidViewModel {

    LiveData<String> error;
    LiveData<Driver> driver;
    LiveData<String> loginStatus;
    LiveData<String> accessToken;

    LoginRepository loginRepository;


    public DriverInfoViewModel(@NonNull Application application) {
        super(application);
        loginRepository=new LoginRepository(application);
        error=loginRepository.getError();
        loginStatus=loginRepository.getLoginStatus();
        driver=loginRepository.getDriver();
        accessToken=loginRepository.getAccessToken();
    }


    public LiveData<String> getAccessToken() {
        return accessToken;
    }

    public boolean getIsLogin(){
        return loginRepository.getIsLogin();
    }

    public void performLogin(String phoneNo){
        loginRepository.performLogin(phoneNo);
    }

    public void verifyCode(String vCode){
        loginRepository.verifyCode(vCode);
    }

    public void resendOTP(String phoneNo){
        loginRepository.resendOTP(phoneNo);
    }

    public LiveData<String> getError() {
        return error;
    }

    public LiveData<Driver> getDriver() {
        return driver;
    }

    public LiveData<String> getLoginStatus() {
        return loginStatus;
    }

    public LiveData<String> getVerificationStatus(){
        return loginRepository.getVerificationStatus();
    }
}
