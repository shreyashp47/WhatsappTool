package com.taxivaxi.driver.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.taxivaxi.driver.tracking.LocationService;

/**
 * Created by sandeep on 24/1/18.
 */

public class OnBootBroadCastReceiver extends BroadcastReceiver {
    SharedPreferences preferences;
    @Override
    public void onReceive(Context context, Intent intent) {
        preferences=context.getSharedPreferences("currentBookingPref",Context.MODE_PRIVATE);
        if(preferences.getBoolean("isCurrentBooking",false)){
            Log.d("isCurrentBooking","True");
            context.startService(new Intent(context,LocationService.class));
        }
        else {
            Log.d("isCurrentBooking","False");
        }

    }
}
