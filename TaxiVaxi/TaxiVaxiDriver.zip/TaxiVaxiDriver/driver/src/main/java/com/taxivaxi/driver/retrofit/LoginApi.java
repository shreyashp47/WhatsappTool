package com.taxivaxi.driver.retrofit;

import com.taxivaxi.driver.models.login.LoginApiResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by sandeep on 4/11/17.
 */

public interface LoginApi {

    @FormUrlEncoded
    @POST(ApiURLs.loginURL)
    Call<LoginApiResponse> performLogin(@Field("contact_no") String contactNo);
}
