package com.taxivaxi.driver.services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.taxivaxi.driver.R;
import com.taxivaxi.driver.activities.DetailsActivity;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.models.upcomingbooking.Passenger;
import com.taxivaxi.driver.utility.GsonStringConvertor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by sandeep on 23/2/18.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private NotificationManager mNotificationManager;
    private String channeId="D2";
    private String channelName="NewBooking";
    private String channeldiscriptuon="New Booking Notification For Driver";
    private int importance= NotificationManager.IMPORTANCE_HIGH;

    void createNotificationChannel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.d("NotificationChannel","Creating");
            NotificationChannel notificationChannel=new NotificationChannel(channeId,channelName,importance);
            notificationChannel.setDescription(channeldiscriptuon);
            notificationChannel.enableLights(true);
            notificationChannel.enableVibration(true);
            notificationChannel.setLightColor(Color.GREEN);
            notificationChannel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
            mNotificationManager.createNotificationChannel(notificationChannel);
            Log.d("NotificationChannel","Created");
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.d("FCMmessage",remoteMessage.getData().toString());

        mNotificationManager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mNotificationManager.getNotificationChannel(channeId)==null){
            createNotificationChannel();
        }

        Map<String,String> map=new HashMap<>(remoteMessage.getData());
        Log.d("Passengers",map.get("Passengers"));

        Passenger[] passengerList=GsonStringConvertor.stringToGson(map.get("Passengers"), Passenger[].class);
        Booking booking=new Booking(map.get("booking_id"),
                map.get("reference_no"),
                map.get("pickup_datetime"),
                map.get("pickup_location"),
                map.get("trip_status"),
                map.get("tour_type"),
                map.get("city_name"),
                map.get("package_name"),
                Arrays.asList(passengerList),
                map.get("drop_location"));

        Intent intent=new Intent(this,DetailsActivity.class);
        intent.putExtra("bookingInfo",GsonStringConvertor.gsonToString(booking));

        PendingIntent pendingIntent=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder mBuilder=new NotificationCompat.Builder(this,channeId)
                .setSmallIcon(R.drawable.driver_icon_yellow)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.driver_icon_yellow))
                .setContentTitle("New Booking Assigned")
                .setContentText("A new booking has been assigned click to see details")
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        mNotificationManager.notify(Integer.parseInt(booking.getBookingId()),mBuilder.build());

    }
}

//{"to":"fZIr8XWl7EQ:APA91bG_58PuL1B8joEIBVeKQwmt8dHuPCmuNQCukaFIuQfJEHLC24gofXdmH0aLZ_n4OyqAF5tjCHWqXO3uQbIB-arRh5lZ4cmXZxevOMzKSjqPoVEpvGJmU9Q9MNl-tUNqreRr61ke","data": {"booking_id":"96fb9b48825b741083d35b0137af1be0","reference_no":"TVTXIVX16038","pickup_datetime":"2018-03-06 15:10:00","pickup_location":"Chattarpur Metro Station Andheria Mor Village, Vasant Kunj, New Delhi, Delhi","drop_location":"Durga Vihar Roshan Vihar 1, Najafgarh, Delhi","trip_status":"Driver Assigned","tour_type":"Outstation","city_name":"New Delhi","package_name":"Outstation","Passengers":[{"id":"4814","admin_id":"21","group_id":"164","subgroup_id":"205","user_id":"217","people_cid":"SAN8765","people_name":"Sandeep","people_email":"joshisandeep2010@gmail.com","people_contact":"9899701993","age":null,"gender":null,"id_proof_type":null,"id_proof_no":null,"is_active":"1","has_dummy_email":"0","fcm_regid":"f2c5jVaw3dY:APA91bH-Fq9qXmu4WSsQVbNA38HB4DH9PJ55fSRCS37shLB3ps8XQlVTvX-TtnnX2un3rV0S-x-3O4ucWxN0QU0_rcD1hgmPbO4Ct6MKcbQdtFmz2SEI1JzaT4nkDWsJSVecxaOa-jwG","created":"2017-12-12 13:31:40","modified":"2017-12-12 13:39:58"}]},"priority":"high"}
