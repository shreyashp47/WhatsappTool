package com.taxivaxi.driver.models.upcomingbooking;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by sandeep on 10/11/17.
 */

public class Passenger {

    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("admin_id")
    @Expose
    public String adminId;
    @SerializedName("group_id")
    @Expose
    public String groupId;
    @SerializedName("subgroup_id")
    @Expose
    public String subgroupId;
    @SerializedName("user_id")
    @Expose
    public String userId;
    @SerializedName("people_cid")
    @Expose
    public String peopleCid;
    @SerializedName("people_name")
    @Expose
    public String peopleName;
    @SerializedName("people_email")
    @Expose
    public String peopleEmail;
    @SerializedName("people_contact")
    @Expose
    public String peopleContact;
    @SerializedName("age")
    @Expose
    public String age;
    @SerializedName("gender")
    @Expose
    public String gender;
    @SerializedName("id_proof_type")
    @Expose
    public String idProofType;
    @SerializedName("id_proof_no")
    @Expose
    public String idProofNo;
    @SerializedName("is_active")
    @Expose
    public String isActive;
    @SerializedName("has_dummy_email")
    @Expose
    public String hasDummyEmail;
    @SerializedName("fcm_regid")
    @Expose
    public String fcmRegid;
    @SerializedName("created")
    @Expose
    public String created;
    @SerializedName("modified")
    @Expose
    public String modified;

    public Passenger() {
    }
}
