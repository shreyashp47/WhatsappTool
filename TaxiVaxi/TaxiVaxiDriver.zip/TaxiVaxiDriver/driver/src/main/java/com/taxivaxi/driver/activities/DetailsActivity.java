package com.taxivaxi.driver.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.fragment.CurrentBookingFragment;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        String details=getIntent().getStringExtra("bookingInfo");
        CurrentBookingFragment currentBookingFragment=new CurrentBookingFragment();
        Bundle bundle=new Bundle();
        bundle.putString("bookingInfo",details);
        bundle.putBoolean("fromNotification",true);
        currentBookingFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.details_container,currentBookingFragment)
                .commit();
    }
}
