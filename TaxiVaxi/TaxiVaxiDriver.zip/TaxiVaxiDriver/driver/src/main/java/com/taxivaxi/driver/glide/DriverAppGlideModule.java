package com.taxivaxi.driver.glide;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by sandeep on 28/2/18.
 */

@GlideModule
public class DriverAppGlideModule extends AppGlideModule {
}
