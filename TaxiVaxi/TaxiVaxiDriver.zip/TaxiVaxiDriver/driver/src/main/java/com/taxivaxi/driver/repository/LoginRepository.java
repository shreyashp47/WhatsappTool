package com.taxivaxi.driver.repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.Context;
import android.content.SharedPreferences;

import com.taxivaxi.driver.models.login.Driver;
import com.taxivaxi.driver.models.login.LoginApiResponse;
import com.taxivaxi.driver.retrofit.ConfigRetrofit;
import com.taxivaxi.driver.retrofit.LoginApi;
import com.taxivaxi.driver.utility.GsonStringConvertor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by sandeep on 4/11/17.
 */

public class LoginRepository {

    private MutableLiveData<Driver> driver;
    private boolean isLogin;
    private LoginApi loginApi;
    private MutableLiveData<String> loginStatus;
    private SharedPreferences sharedPreferences;
    private MutableLiveData<String> error;
    private MutableLiveData<String> verificationStatus;
    private MutableLiveData<String> accessToken;

    public LoginRepository(Application application){
      driver=new MutableLiveData<>();
      loginStatus=new MutableLiveData<>();
      loginApi= ConfigRetrofit.configRetrofit(LoginApi.class);
      error=new MutableLiveData<>();
      sharedPreferences=application.getSharedPreferences("driverPref", Context.MODE_PRIVATE);
      isLogin=sharedPreferences.getBoolean("isLogin",false);
      verificationStatus=new MutableLiveData<>();
      accessToken=new MutableLiveData<>();
      if (sharedPreferences.getString("driverInfo",null)!=null) {
          driver.setValue(GsonStringConvertor.stringToGson(sharedPreferences.getString("driverInfo", null), Driver.class));
          accessToken.setValue(sharedPreferences.getString("accessToken",null));
      }
    }

    public boolean getIsLogin(){
        return  sharedPreferences.getBoolean("isLogin",false);
    }

    public MutableLiveData<Driver> getDriver() {
        return driver;
    }

    public MutableLiveData<String> getLoginStatus() {
        return loginStatus;
    }

    public MutableLiveData<String> getError() {
        return error;
    }

    public MutableLiveData<String> getAccessToken() {
        return accessToken;
    }

    public MutableLiveData<String> getVerificationStatus() {
        return verificationStatus;
    }


    public void performLogin(String phoneNo){
        loginApi.performLogin(phoneNo).enqueue(new Callback<LoginApiResponse>() {
            @Override
            public void onResponse(Call<LoginApiResponse> call, Response<LoginApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1") && response.body().getResponse()!=null){
                        driver.setValue(response.body().getResponse().getDriver());
                        accessToken.setValue(response.body().getResponse().getAccessToken());
                        loginStatus.setValue("successful");
                    }else {
                        error.setValue(response.body().getError());
                    }
                }
                else {
                    error.setValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<LoginApiResponse> call, Throwable t) {
                error.setValue("Connection Error: "+t.getMessage());
            }
        });
    }

    public void resendOTP(String phoneNo){
        loginApi.performLogin(phoneNo).enqueue(new Callback<LoginApiResponse>() {
            @Override
            public void onResponse(Call<LoginApiResponse> call, Response<LoginApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1") && response.body().getResponse()!=null){
                        driver.setValue(response.body().getResponse().getDriver());
                        loginStatus.setValue("otp sent successfully");
                    }else {
                        error.setValue(response.body().getError());
                    }
                }
                else {
                    error.setValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<LoginApiResponse> call, Throwable t) {
                error.setValue("Connection Error: "+t.getMessage());
            }
        });
    }


    public void verifyCode(String verificationCode){
        if (verificationCode.equals(driver.getValue().getValidationCode())){
            verificationStatus.setValue("successful");
            sharedPreferences.edit().putBoolean("isLogin",true)
                    .putString("accessToken",accessToken.getValue())
                    .putString("driverInfo",GsonStringConvertor.gsonToString(driver.getValue()))
                    .commit();
        }
        else {
            verificationStatus.setValue("unsuccessful");
        }
    }


}
