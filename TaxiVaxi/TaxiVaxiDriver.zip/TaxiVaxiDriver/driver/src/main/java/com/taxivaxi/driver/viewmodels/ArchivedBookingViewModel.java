package com.taxivaxi.driver.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;
import android.widget.ProgressBar;

import com.taxivaxi.driver.models.archivedbooking.Booking;
import com.taxivaxi.driver.repository.ArchivedBookingRepository;

import java.util.List;

/**
 * Created by sandeep on 7/2/18.
 */

public class ArchivedBookingViewModel extends AndroidViewModel {

    ArchivedBookingRepository archivedBookingRepository;
    LiveData<List<Booking>> archivedBookingList;
    LiveData<String> error;

    public ArchivedBookingViewModel(@NonNull Application application) {
        super(application);
        archivedBookingRepository=new ArchivedBookingRepository();
        archivedBookingList=archivedBookingRepository.getArchivedBookingList();
        error=archivedBookingRepository.getError();
    }

    public LiveData<List<Booking>> getArchivedBookingList() {
        return archivedBookingList;
    }

    public LiveData<String> getError() {
        return error;
    }

    public void getArchivedBookings(String accessToken){
        archivedBookingRepository.getArchivedBookings(accessToken);
    }
}
