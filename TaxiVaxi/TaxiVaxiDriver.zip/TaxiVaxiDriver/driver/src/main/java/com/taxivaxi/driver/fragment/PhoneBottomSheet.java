package com.taxivaxi.driver.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.adapter.CallUserAdapter;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.models.upcomingbooking.Passenger;
import com.taxivaxi.driver.utility.GsonStringConvertor;

import java.util.List;

/**
 * Created by sandeep on 29/1/18.
 */

public class PhoneBottomSheet extends BottomSheetDialogFragment implements CallUserAdapter.CallUserEventListener {

    View view;
    RecyclerView recyclerView;
    CallUserAdapter callUserAdapter;
    Booking booking;
    TextView bookingId;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.bottomsheet_phone,container,false);
        recyclerView=view.findViewById(R.id.phone_bottomsheet_recyclerview);
        bookingId=view.findViewById(R.id.booking_id);
        Bundle bundle=getArguments();
        booking= GsonStringConvertor.stringToGson(bundle.getString("bookingInfo"),Booking.class);
        callUserAdapter=new CallUserAdapter(this,booking.getPassengers());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity(),
                LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(callUserAdapter);

        bookingId.setText("Booking ID: "+booking.getReferenceNo());
        return view;
    }

    @Override
    public void onCallClicked(String contactNo) {
      Log.d("Event",contactNo);
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + "+91"+contactNo));
        startActivity(intent);
    }
}
