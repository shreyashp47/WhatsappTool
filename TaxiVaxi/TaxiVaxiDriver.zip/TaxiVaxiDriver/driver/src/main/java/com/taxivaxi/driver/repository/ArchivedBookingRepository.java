package com.taxivaxi.driver.repository;

import android.arch.lifecycle.MutableLiveData;

import com.taxivaxi.driver.models.archivedbooking.ArchivedBookingApiResponse;
import com.taxivaxi.driver.models.archivedbooking.Booking;
import com.taxivaxi.driver.retrofit.ArchivedBookingAPI;
import com.taxivaxi.driver.retrofit.ConfigRetrofit;
import com.taxivaxi.driver.utility.GsonStringConvertor;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by sandeep on 6/2/18.
 */

public class ArchivedBookingRepository {

    MutableLiveData<List<Booking>> archivedBookingList;
    MutableLiveData<String> error;
    ArchivedBookingAPI archivedBookingAPI;

    public ArchivedBookingRepository(){
        archivedBookingList=new MutableLiveData<>();
        error=new MutableLiveData<>();
        archivedBookingAPI= ConfigRetrofit.configRetrofit(ArchivedBookingAPI.class);
    }

    public MutableLiveData<List<Booking>> getArchivedBookingList() {
        return archivedBookingList;
    }

    public MutableLiveData<String> getError() {
        return error;
    }

    public void getArchivedBookings(String accessToken){
        archivedBookingAPI.getArchivedBookings(accessToken).enqueue(new Callback<ArchivedBookingApiResponse>() {
            @Override
            public void onResponse(Call<ArchivedBookingApiResponse> call, Response<ArchivedBookingApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1") && response.body().getResponse()!=null){
                        archivedBookingList.setValue(response.body().getResponse().getBookings());
                    }
                    else {
                        error.setValue(response.body().getError());
                    }
                }
                else {
                    error.setValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<ArchivedBookingApiResponse> call, Throwable t) {
                error.setValue("Connection Error: "+t.getMessage());
            }
        });
    }
}
