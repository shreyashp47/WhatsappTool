package com.taxivaxi.driver.repository;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.taxivaxi.driver.models.updatefcmmodel.UpdateFcmTokenApiResponse;
import com.taxivaxi.driver.retrofit.ConfigRetrofit;
import com.taxivaxi.driver.retrofit.UpdateFcmTokenAPI;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by sandeep on 22/2/18.
 */

public class UpdateFcmTokenRepository {

    private SharedPreferences fcmPref;
    private UpdateFcmTokenAPI updateFcmTokenAPI;
    private String fcmToken;

    public UpdateFcmTokenRepository(Application application) {
        fcmPref=application.getSharedPreferences("fcmPref", Context.MODE_PRIVATE);
        updateFcmTokenAPI= ConfigRetrofit.configRetrofit(UpdateFcmTokenAPI.class);
        fcmToken=fcmPref.getString("fcmToken","n");
    }


    public boolean getIsTokenUpdated(String fcmToken){
        if (!fcmPref.getString("fcmPref","n").equals("n") && fcmToken.equals(fcmPref.getString("fcmPref","n"))){
            return true;
        }else {
            return false;
        }
    }

    public void updateFcmToken(String accessToken, String authType, String fcmToken){
        updateFcmTokenAPI.updateFcmToken(accessToken, authType, fcmToken).enqueue(new Callback<UpdateFcmTokenApiResponse>() {
            @Override
            public void onResponse(Call<UpdateFcmTokenApiResponse> call, Response<UpdateFcmTokenApiResponse> response) {

                if (response.isSuccessful()) {
                    if (response.body().getSuccess().equals("1")) {
                        fcmPref.edit().putBoolean("isTokenUpdated", true);
                    }
                }
            }

            @Override
            public void onFailure(Call<UpdateFcmTokenApiResponse> call, Throwable t) {

            }
        });
    }



}
