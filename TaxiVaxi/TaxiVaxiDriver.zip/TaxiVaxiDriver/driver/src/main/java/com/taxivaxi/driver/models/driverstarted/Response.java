package com.taxivaxi.driver.models.driverstarted;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by sandeep on 15/11/17.
 */

public class Response {
    @SerializedName("access_token")
    @Expose
    public String accessToken;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("notification_for")
    @Expose
    public String notificationFor;
    @SerializedName("driver_location")
    @Expose
    public Object driverLocation;
    @SerializedName("status")
    @Expose
    public String status;
    @SerializedName("status_color")
    @Expose
    public String statusColor;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getNotificationFor() {
        return notificationFor;
    }

    public void setNotificationFor(String notificationFor) {
        this.notificationFor = notificationFor;
    }

    public Object getDriverLocation() {
        return driverLocation;
    }

    public void setDriverLocation(Object driverLocation) {
        this.driverLocation = driverLocation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusColor() {
        return statusColor;
    }

    public void setStatusColor(String statusColor) {
        this.statusColor = statusColor;
    }
}
