package com.taxivaxi.driver.activities;

import android.arch.lifecycle.ViewModelProviders;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;
import android.view.MenuItem;

import com.google.firebase.iid.FirebaseInstanceId;
import com.taxivaxi.driver.R;
import com.taxivaxi.driver.fragment.HomeFragment;
import com.taxivaxi.driver.fragment.ProfileFragment;
import com.taxivaxi.driver.fragment.StartJourneyDialog;
import com.taxivaxi.driver.viewmodels.DriverInfoViewModel;
import com.taxivaxi.driver.viewmodels.UpdateFcmTokenViewModel;

public class HomeActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    BottomNavigationView bottomNavigationView;
    UpdateFcmTokenViewModel updateFcmTokenViewModel;
    DriverInfoViewModel driverInfoViewModel;
    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bottomNavigationView=findViewById(R.id.navigation);

        updateFcmTokenViewModel= ViewModelProviders.of(this).get(UpdateFcmTokenViewModel.class);
        driverInfoViewModel=ViewModelProviders.of(this).get(DriverInfoViewModel.class);

        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        String fcmToken= FirebaseInstanceId.getInstance().getToken();
        if (fcmToken!=null && !updateFcmTokenViewModel.isTokenUpdated(fcmToken)){
            Log.d("FcmToken",fcmToken);
            updateFcmTokenViewModel.updateFcmToken(driverInfoViewModel.getAccessToken().getValue(),"driver",fcmToken);
        }

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container,new HomeFragment())
                .commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_home:
                FragmentManager fm = getSupportFragmentManager();
                int count = fm.getBackStackEntryCount();
                for(int i = 0; i < count; ++i) {
                    fm.popBackStack();
                }
                break;
            case R.id.action_profile:
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container,new ProfileFragment())
                        .addToBackStack(null)
                        .commit();
        }
        return false;
    }
}
