package com.taxivaxi.driver.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.repository.UpcomingBookingsRepository;

import java.util.List;

/**
 * Created by sandeep on 13/11/17.
 */

public class UpcomingBookingViewModel extends AndroidViewModel{

    UpcomingBookingsRepository upcomingBookingsRepository;
    LiveData<List<Booking>> upcomingBookingList;
    LiveData<String> error;


    public UpcomingBookingViewModel(@NonNull Application application) {
        super(application);
        upcomingBookingsRepository=UpcomingBookingsRepository.getInstance();
        upcomingBookingList=upcomingBookingsRepository.getUpcomingBookings();
        error=upcomingBookingsRepository.getError();
    }

    public LiveData<List<Booking>> getUpcomingBookingList() {
        return upcomingBookingList;
    }

    public LiveData<String> getError() {
        return error;
    }

    public void deleteUpcomingBookingList(){
        upcomingBookingsRepository.deleteUpcomingBookingList();
    }

    public void getUpcomingBookings(String accessToken){
        upcomingBookingsRepository.getUpcomingBooking(accessToken);
    }

}
