package com.taxivaxi.driver.retrofit;

import com.taxivaxi.driver.models.upcomingbooking.UpcomingBookingApiResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by sandeep on 13/11/17.
 */

public interface UpcomingBookingAPI {

    @FormUrlEncoded
    @POST(ApiURLs.upcomingBookingURL)
    Call<UpcomingBookingApiResponse> getUpcomingBooking(@Field("access_token")String accessToken);
}
