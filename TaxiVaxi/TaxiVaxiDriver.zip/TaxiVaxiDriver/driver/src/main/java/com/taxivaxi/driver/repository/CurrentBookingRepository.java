package com.taxivaxi.driver.repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.PolyUtil;
import com.taxivaxi.driver.models.driverarrived.DriverArrivedApiResponse;
import com.taxivaxi.driver.models.driverstarted.DriverStartedApiResponse;
import com.taxivaxi.driver.models.endride.EndRideApiResponse;
import com.taxivaxi.driver.models.startride.StartRideApiResponse;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.retrofit.ConfigRetrofit;
import com.taxivaxi.driver.retrofit.DriverStartedAPI;
import com.taxivaxi.driver.utility.GsonStringConvertor;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by sandeep on 14/11/17.
 */

public class CurrentBookingRepository {
    public static CurrentBookingRepository INSTANCE=null;
    SharedPreferences currentBookingPref;
    SharedPreferences trackingBookingPref;
    MutableLiveData<Booking> booking;
    MutableLiveData<Boolean> isCurrentBooking;
    MutableLiveData<String> tripStatus;
    MutableLiveData<DriverStartedApiResponse> driverStartedApiResponse;
    MutableLiveData<String> error;
    MutableLiveData<String> status;
    MutableLiveData<Boolean> hasEnteredAtPickupPoint;
    String garageLocation;
    DriverStartedAPI driverStartedAPI;
    String initialKms;
    String finalKms;
    Location lastLocation;

    private CurrentBookingRepository(Application application){
        isCurrentBooking=new MutableLiveData<>();
        booking=new MutableLiveData<>();
        tripStatus=new MutableLiveData<>();
        error=new MutableLiveData<>();
        driverStartedApiResponse=new MutableLiveData<>();
        status=new MutableLiveData<>();
        garageLocation=new String();
        hasEnteredAtPickupPoint=new MutableLiveData<>();
        driverStartedAPI= ConfigRetrofit.configRetrofit(DriverStartedAPI.class);
        currentBookingPref=application.getSharedPreferences("currentBookingPref", MODE_PRIVATE);
        trackingBookingPref=application.getSharedPreferences("trackingPref",MODE_PRIVATE);
        isCurrentBooking.setValue(currentBookingPref.getBoolean("isCurrentBooking",false));
        tripStatus.setValue(currentBookingPref.getString("tripStatus","0"));
        if (!currentBookingPref.getString("currentBooking","n").equals("n")){
            booking.setValue(GsonStringConvertor.stringToGson(currentBookingPref.getString("currentBooking","n"),Booking.class));
        }
    }

    public static CurrentBookingRepository getInstance(Application application){
        if (INSTANCE==null){
            INSTANCE=new CurrentBookingRepository(application);
        }
        return INSTANCE;
    }

    public MutableLiveData<Boolean> getHasEnteredAtPickupPoint() {
        return hasEnteredAtPickupPoint;
    }

    public Boolean getPaused() {
        return trackingBookingPref.getBoolean("isPaused",false);
    }

    public void setPaused(boolean isPaused){
        trackingBookingPref.edit().putBoolean("isPaused",isPaused).commit();
    }

    public void setHasEnteredAtPickupPoint(Boolean hasEnteredAtPickupPoint) {
        this.hasEnteredAtPickupPoint.postValue(hasEnteredAtPickupPoint);
    }

    public MutableLiveData<String> getError() {
        return error;
    }

    public LiveData<String> getStatus() {
        return status;
    }

    public LatLng getGarageLocation() {
        Log.d("GarageLocation",currentBookingPref.getString("garage","n"));
        if (!currentBookingPref.getString("garage","n").equals("n")){
           return GsonStringConvertor.stringToGson(
                   currentBookingPref.getString("garage","n"),LatLng.class);
        }
        return null;
    }

    public void setGarageLocation(LatLng garageLocation){
        Log.d("GarageLocation",GsonStringConvertor.gsonToString(garageLocation));
        currentBookingPref.edit().putString("garage",GsonStringConvertor.gsonToString(garageLocation)).commit();
        Log.d("GarageLocation",currentBookingPref.getString("garage","n"));
    }

    public LatLng getStartingLocation(){
        if (!currentBookingPref.getString("startingLocation","n").equals("n")){
            return GsonStringConvertor.stringToGson(currentBookingPref.getString("startingLocation","n"),LatLng.class);
        }
        return null;
    }

    public void setStartingLocation(LatLng startingLocation){
        currentBookingPref.edit().putString("startingLocation",GsonStringConvertor.gsonToString(startingLocation)).commit();
    }

    public LiveData<Booking> getBooking() {
        if (!currentBookingPref.getString("bookingInfo","n").equals("n")) {
            booking.setValue(GsonStringConvertor.stringToGson(currentBookingPref.getString("bookingInfo", "n"), Booking.class));
        }
        return booking;
    }

    public MutableLiveData<String> getTripStatus() {
        return tripStatus;
    }

    public void setTripStatus(String tripStatus){
        this.tripStatus.setValue(tripStatus);
        currentBookingPref.edit().putString("tripStatus",tripStatus).commit();
    }

    public LiveData<Boolean> getIsCurrentBooking() {
        return isCurrentBooking;
    }

    public String getInitialKms() {
        return initialKms;
    }

    public String getFinalKms() {
        return finalKms;
    }

    public void setBooking(String booking) {
        this.booking.setValue(GsonStringConvertor.stringToGson(booking,Booking.class));
        currentBookingPref.edit().putString("bookingInfo",booking).commit();
    }

    public double getStartKm(){
        double startKm=Double.parseDouble(currentBookingPref.getString("start_km","0"));
        Log.d("StartKm",startKm+"");
        return startKm;
    }

    public void setIsCurrentBooking(boolean isCurrentBooking) {
        this.isCurrentBooking.setValue(isCurrentBooking);
        currentBookingPref.edit().putBoolean("isCurrentBooking",isCurrentBooking).commit();
    }


    public void setInitialKms(String initialKms) {
        this.initialKms = initialKms;
        currentBookingPref.edit().putString("initialKms",initialKms).commit();
    }

    public void setFinalKms(String finalKms) {
        this.finalKms = finalKms;
        currentBookingPref.edit().putString("finalKms",finalKms).commit();
    }

    public void reSetStatus(){
        status.setValue("Empty");
    }


    public void initiateDriver(String accessToken,String bookingId,String garageLocation,String startKm){
        driverStartedAPI.triggerDriverStarted(accessToken,bookingId,garageLocation,startKm).enqueue(new Callback<DriverStartedApiResponse>() {
            @Override
            public void onResponse(Call<DriverStartedApiResponse> call, Response<DriverStartedApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1") && response.body().getResponse()!=null){
                        status.setValue("driver started successfully");
                    }
                    else {
                        error.setValue(response.body().getError());
                    }
                }else {
                    error.setValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<DriverStartedApiResponse> call, Throwable t) {
                error.setValue("Connection Error:"+t.getMessage());
            }
        });
    }

    public void initiatedArrived(String accessToken,String bookingId,String garageDistance,String measuredGarageDistance){
        driverStartedAPI.initiateDriverArrived(accessToken, bookingId, garageDistance,measuredGarageDistance).enqueue(new Callback<DriverArrivedApiResponse>() {
            @Override
            public void onResponse(Call<DriverArrivedApiResponse> call, Response<DriverArrivedApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1") && response.body().getResponse()!=null){
                        status.setValue("driver arrived at pickup point");
                        Log.d("StartOtp",response.body().getResponse().getTripDetails().getStartOtp());
                        setStartOtp(response.body().getResponse().getTripDetails().getStartOtp());
                    }
                    else {
                        error.setValue(response.body().getError());
                    }
                }else {
                    error.setValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<DriverArrivedApiResponse> call, Throwable t) {
                error.setValue("Connection Error");
            }
        });
    }

    public void initiateStartRide(String accessToken, String bookingId, String startLocation, final String startKm){
        driverStartedAPI.initiateStartRide(accessToken, bookingId, startLocation,startKm).enqueue(new Callback<StartRideApiResponse>() {
            @Override
            public void onResponse(Call<StartRideApiResponse> call, Response<StartRideApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1") && response.body().getResponse()!=null){
                        status.setValue("ride started");
                        setEndOtp(response.body().getResponse().getTripDetails().getEndOtp());
                        Log.d("EndOtp",response.body().getResponse().getTripDetails().getEndOtp());
                        currentBookingPref.edit().putString("start_km",startKm).commit();
                    }
                    else{
                        error.setValue("Connection Error");
                    }
                }
                else {
                    error.setValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<StartRideApiResponse> call, Throwable t) {
                error.setValue("Connection Error");
            }
        });
    }

    public void initiateEndRide(String accessToken,String bookingId,String dropLocation,String garageDistanceFromDrop,
                                String endKm,String stateTax,String parking,String tollTax,String otherTax,String estimatedDistance,
                                String estimateGarageDistance,String estimateTimeToReachGarage,String calculatedTripDistance){
        driverStartedAPI.initiateEndRide(accessToken, bookingId, dropLocation, garageDistanceFromDrop,
                endKm, stateTax, parking, tollTax,otherTax,estimatedDistance, estimateGarageDistance,
                estimateTimeToReachGarage,calculatedTripDistance).enqueue(new Callback<EndRideApiResponse>() {
            @Override
            public void onResponse(Call<EndRideApiResponse> call, Response<EndRideApiResponse> response) {
                if (response.isSuccessful()){
                    if (response.body().getSuccess().equals("1") && response.body().getResponse()!=null){
                        status.setValue("ride ended");
                    }
                    else {
                        error.setValue(response.body().getError());
                    }
                }else {
                    error.setValue("Connection Error");
                }
            }

            @Override
            public void onFailure(Call<EndRideApiResponse> call, Throwable t) {
                error.setValue("Connection Error");
            }
        });
    }

    public void deleteData(){
        currentBookingPref.edit().clear().commit();
        status.setValue("new");
        tripStatus.setValue("0");
        Log.d("tripStatus",tripStatus.getValue());
        booking.setValue(null);
        isCurrentBooking.setValue(false);
    }

    public void setStartOtp(String startOtp){
        currentBookingPref.edit().putString("startOtp",startOtp).commit();
    }

    public String getStartOtp(){
        return currentBookingPref.getString("startOtp","unavailable");
    }

    public String getEndOtp(){
        return currentBookingPref.getString("endOtp","unavailable");
    }

    public void setEndOtp(String endOtp){
        currentBookingPref.edit().putString("endOtp",endOtp).commit();
    }

    public void setPolyLine(Location location){
        if (lastLocation==null ||currentBookingPref.getString("polyline",null)==null ){
            List<LatLng> polyLatLng=new ArrayList<>();
            polyLatLng.add(new LatLng(location.getLatitude(),location.getLongitude()));
            currentBookingPref.edit().putString("polyline",PolyUtil.encode(polyLatLng)).commit();
            Log.d("PolyLine","Created");
            lastLocation=location;
        }else
        if (lastLocation.distanceTo(location)>=7){
            String polyLine=currentBookingPref.getString("polyline",null);
            List<LatLng> polyLatLng=PolyUtil.decode(polyLine);
            polyLatLng.add(new LatLng(location.getLatitude(),location.getLongitude()));
            currentBookingPref.edit().putString("polyline",PolyUtil.encode(polyLatLng)).commit();
            Log.d("PolyLine","Appended");
            lastLocation=location;
        }
        else {
            Log.d("PolyLine","Inspected");
        }

    }

    public String getPolyLine(){
        return currentBookingPref.getString("polyline",null);
    }

}
