package com.taxivaxi.driver.fragment;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;
import com.taxivaxi.driver.R;
import com.taxivaxi.driver.activities.MainActivity;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.utility.GsonStringConvertor;
import com.taxivaxi.driver.viewmodels.CurrentBookingViewModel;
import com.taxivaxi.driver.viewmodels.DriverInfoViewModel;
import com.taxivaxi.driver.viewmodels.UpcomingBookingViewModel;

import java.util.List;


/**
 * Fragment to shoe home/landing screen of the screen.
 */
public class HomeFragment extends Fragment implements View.OnClickListener{

    View view;
    LinearLayout upcomingBookingLay; //layout represents upcoming bookings.
    LinearLayout currentBookingLay;  //layout represents current bookings.
    LinearLayout archivedBookingLay; //layout represents archived bookings.
    TextView driverName; //TextView driver name.
    CurrentBookingViewModel currentBookingViewModel; //current booking ViewModel to get current booking data.
    DriverInfoViewModel driverInfoViewModel;  //driver info ViewModel to get driver information.
    UpcomingBookingViewModel upcomingBookingViewModel;  //
    ProgressBar progressBar;


    public HomeFragment() {
        // Required empty public constructor
    }

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view= inflater.inflate(R.layout.fragment_landing, container, false);
        currentBookingViewModel= ViewModelProviders.of(this).get(CurrentBookingViewModel.class);
        driverInfoViewModel=ViewModelProviders.of(getActivity()).get(DriverInfoViewModel.class);
        upcomingBookingViewModel=ViewModelProviders.of(this).get(UpcomingBookingViewModel.class);
        upcomingBookingLay=view.findViewById(R.id.upcoming_booking_lay);
        currentBookingLay=view.findViewById(R.id.current_booking_lay);
        archivedBookingLay=view.findViewById(R.id.archived_booking_lay);
        driverName=view.findViewById(R.id.driver_name);
        progressBar=view.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        currentBookingLay.setOnClickListener(this);
        upcomingBookingLay.setOnClickListener(this);
        archivedBookingLay.setOnClickListener(this);

        LatLng latLng=new LatLng(300,300);

        driverName.setText(driverInfoViewModel.getDriver().getValue().driverName);

      if (currentBookingViewModel.getIsCurrentBooking()){
            Intent intent=new Intent(getActivity(), MainActivity.class);
            intent.putExtra("bookingInfo", GsonStringConvertor.gsonToString(currentBookingViewModel.getCurrentBooking().getValue()));
            Log.d("bookingInfo",GsonStringConvertor.gsonToString(currentBookingViewModel.getCurrentBooking().getValue()));
            startActivity(intent);
            getActivity().finish();

      }

      upcomingBookingViewModel.getUpcomingBookingList().observe(this, new Observer<List<Booking>>() {
          @Override
          public void onChanged(@Nullable List<Booking> bookings) {
              if (bookings!=null && bookings.size()>0){
                  progressBar.setVisibility(View.GONE);
                  Log.d("Booking","Available");
                  Intent intent=new Intent(getActivity(), MainActivity.class);
                  intent.putExtra("bookingInfo", GsonStringConvertor.gsonToString(bookings.get(0)));
                  upcomingBookingViewModel.deleteUpcomingBookingList();
                  startActivity(intent);

                /* Fragment fragment=new CurrentBookingFragment();
                 Bundle args=new Bundle();
                 args.putString("bookingInfo",GsonStringConvertor.gsonToString(bookings.get(0)));
                 fragment.setArguments(args);
                  getFragmentManager().beginTransaction()
                          .replace(R.id.container,fragment)
                          .addToBackStack(null)
                          .commit();
                  upcomingBookingViewModel.deleteUpcomingBookingList();
                  */
                  //Snackbar.make(view,"No Booking Available",Snackbar.LENGTH_LONG).show();
              }
          }
      });

      upcomingBookingViewModel.getError().observe(this, new Observer<String>() {
          @Override
          public void onChanged(@Nullable String s) {
              if (s!=null && s.length()>0){
                  progressBar.setVisibility(View.GONE);
                  Snackbar.make(view,s,Snackbar.LENGTH_LONG).show();
              }
          }
      });


    return view;

    }

    @Override
    public void onResume() {
        super.onResume();
        getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.backgroungBlue));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.current_booking_lay:
                if (currentBookingViewModel.getIsCurrentBooking()){
                    Intent intent=new Intent(getActivity(), MainActivity.class);
                    intent.putExtra("bookingInfo", GsonStringConvertor.gsonToString(currentBookingViewModel.getCurrentBooking().getValue()));
                    Log.d("bookingInfo",GsonStringConvertor.gsonToString(currentBookingViewModel.getCurrentBooking().getValue()));
                    startActivity(intent);
                }
                else {
                    progressBar.setVisibility(View.VISIBLE);
                    upcomingBookingViewModel.getUpcomingBookings(driverInfoViewModel.getAccessToken().getValue());
                }
                break;
            case R.id.upcoming_booking_lay:
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container,new UpcomingBookingsFragment())
                        .addToBackStack(null)
                        .commit();
                break;
            case R.id.archived_booking_lay:
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container,new ArchivedBookingFragment())
                        .addToBackStack(null)
                        .commit();
                //Snackbar.make(view,"Coming Soon",Snackbar.LENGTH_LONG).show();
                break;
        }

    }
}
