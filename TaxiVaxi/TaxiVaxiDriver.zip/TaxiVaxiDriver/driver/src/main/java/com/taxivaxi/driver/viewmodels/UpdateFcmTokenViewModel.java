package com.taxivaxi.driver.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import com.taxivaxi.driver.repository.UpdateFcmTokenRepository;

/**
 * Created by sandeep on 22/2/18.
 */

public class UpdateFcmTokenViewModel extends AndroidViewModel {

    UpdateFcmTokenRepository updateFcmTokenRepository;

    public UpdateFcmTokenViewModel(@NonNull Application application) {
        super(application);
        updateFcmTokenRepository=new UpdateFcmTokenRepository(application);
    }

    public void updateFcmToken(String accessToken,String authType,String fcmToken){
        updateFcmTokenRepository.updateFcmToken(accessToken,authType,fcmToken);
    }

    public boolean isTokenUpdated(String fcmToken){
        return updateFcmTokenRepository.getIsTokenUpdated(fcmToken);
    }
}
