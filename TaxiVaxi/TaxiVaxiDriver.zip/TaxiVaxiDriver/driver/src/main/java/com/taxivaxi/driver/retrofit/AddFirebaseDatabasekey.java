package com.taxivaxi.driver.retrofit;

import com.taxivaxi.driver.models.registerfcm.RegisterFirebaseDatabaseResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by sandeep on 17/11/17.
 */

public interface AddFirebaseDatabasekey {

    @FormUrlEncoded
    @POST(ApiURLs.addFirebaseKey)
    Call<RegisterFirebaseDatabaseResponse> addFirebaseKey(@Field("access_token") String accessToken,
                                                          @Field("booking_id") String bookingId,
                                                          @Field("firebase_key") String firebaseKey);
}
