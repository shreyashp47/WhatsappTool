package com.taxivaxi.driver.fragment;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.activities.MainActivity;
import com.taxivaxi.driver.adapter.CallUserAdapter;
import com.taxivaxi.driver.adapter.UpcomingBookingAdapter;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.models.upcomingbooking.Passenger;
import com.taxivaxi.driver.utility.GsonStringConvertor;
import com.taxivaxi.driver.utility.NetworkStatus;
import com.taxivaxi.driver.viewmodels.CurrentBookingViewModel;
import com.taxivaxi.driver.viewmodels.DriverInfoViewModel;
import com.taxivaxi.driver.viewmodels.UpcomingBookingViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpcomingBookingsFragment extends Fragment implements UpcomingBookingAdapter.RecyclerViewEventListener,
CallUserAdapter.CallUserEventListener{


    View view;
    UpcomingBookingViewModel upcomingBookingViewModel;
    DriverInfoViewModel driverInfoViewModel;
    List<Booking> bookingList;
    UpcomingBookingAdapter upcomingBookingAdapter;
    CurrentBookingViewModel currentBookingViewModel;
    RecyclerView recyclerView;
    Toolbar toolbar;
    ProgressBar progressBar;


    public UpcomingBookingsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.statusGrey));
        view= inflater.inflate(R.layout.fragment_upcoming_bookings, container, false);
        toolbar=view.findViewById(R.id.toolbar);
        toolbar.setTitle("Upcoming Booking");
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        upcomingBookingViewModel= ViewModelProviders.of(this).get(UpcomingBookingViewModel.class);
        driverInfoViewModel=ViewModelProviders.of(getActivity()).get(DriverInfoViewModel.class);
        recyclerView=view.findViewById(R.id.upcoming_recycleview);
        progressBar=view.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);

        bookingList=new ArrayList<>();
        upcomingBookingAdapter=new UpcomingBookingAdapter(this,bookingList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext(),
                LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(upcomingBookingAdapter);

        upcomingBookingViewModel.getUpcomingBookingList().observe(this, new Observer<List<Booking>>() {
            @Override
            public void onChanged(@Nullable List<Booking> bookings) {
                Log.d("UpcomingBookings", GsonStringConvertor.gsonToString(bookings));
                progressBar.setVisibility(View.GONE);
                if (bookings.size()>0) {
                    bookingList.clear();
                    bookingList.addAll(bookings);
                    upcomingBookingAdapter.notifyDataSetChanged();
                }

            }
        });

        upcomingBookingViewModel.getError().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                progressBar.setVisibility(View.GONE);
                if (s!=null){
                    Snackbar.make(view,s,Snackbar.LENGTH_LONG).show();
                }
            }
        });

        return view;
    }

    @Override
    public void onDetailsClicked(Booking booking) {
        if (NetworkStatus.isInternetConnected(getActivity().getApplication())) {
            Intent intent = new Intent(getActivity(), MainActivity.class);
            intent.putExtra("bookingInfo", GsonStringConvertor.gsonToString(booking));
            startActivity(intent);
        }
        else {
            Toast.makeText(getActivity(),"Internet Connection Unavailable",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        upcomingBookingViewModel.getUpcomingBookings(driverInfoViewModel.getAccessToken().getValue());
    }

    @Override
    public void onCallClicked(String contactNo) {

    }
}
