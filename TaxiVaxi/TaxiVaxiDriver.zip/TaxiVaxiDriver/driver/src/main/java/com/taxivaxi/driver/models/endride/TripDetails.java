package com.taxivaxi.driver.models.endride;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by sandeep on 17/11/17.
 */

public class TripDetails {
    @SerializedName("booking_id")
    @Expose
    public String bookingId;
    @SerializedName("reference_no")
    @Expose
    public String referenceNo;
    @SerializedName("pickup_datetime")
    @Expose
    public String pickupDatetime;
    @SerializedName("pickup_location")
    @Expose
    public String pickupLocation;
    @SerializedName("trip_status")
    @Expose
    public String tripStatus;
    @SerializedName("tour_type")
    @Expose
    public String tourType;
    @SerializedName("city_name")
    @Expose
    public String cityName;
    @SerializedName("package_name")
    @Expose
    public String packageName;
    @SerializedName("fcm_regid")
    @Expose
    public String fcmRegid;
    @SerializedName("firebase_key")
    @Expose
    public Object firebaseKey;
    @SerializedName("start_km")
    @Expose
    public String startKm;
    @SerializedName("garage_distance_from_pickup")
    @Expose
    public String garageDistanceFromPickup;
    @SerializedName("garage_distance_from_drop")
    @Expose
    public String garageDistanceFromDrop;
    @SerializedName("driver_start_time")
    @Expose
    public String driverStartTime;
    @SerializedName("driver_pickup_reach_time")
    @Expose
    public String driverPickupReachTime;
    @SerializedName("ride_start_time")
    @Expose
    public String rideStartTime;
    @SerializedName("ride_end_time")
    @Expose
    public String rideEndTime;
    @SerializedName("end_km")
    @Expose
    public Object endKm;
    @SerializedName("Passengers")
    @Expose
    public List<Passenger> passengers = null;
}
