package com.taxivaxi.driver.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.activities.HomeActivity;
import com.taxivaxi.driver.models.upcomingbooking.Booking;
import com.taxivaxi.driver.utility.GsonStringConvertor;

/**
 * A simple {@link Fragment} subclass.
 */
public class BookingCompletedFragment extends Fragment implements View.OnClickListener{


    public BookingCompletedFragment() {
        // Required empty public constructor
    }

    View view;
    Booking booking;
    TextView bookingId;
    TextView date;
    TextView fromCity;
    TextView toCity;
    Button ok;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().getWindow().setStatusBarColor(getResources().getColor(R.color.green));
        view=inflater.inflate(R.layout.fragment_booking_completed,container,false);
        booking= GsonStringConvertor.stringToGson(getArguments().getString("booking"),Booking.class);
        bookingId=view.findViewById(R.id.booking_id);
        date=view.findViewById(R.id.date);
        fromCity=view.findViewById(R.id.from_city);
        toCity=view.findViewById(R.id.to_city);
        ok=view.findViewById(R.id.btn_ok);

        bookingId.setText(booking.getReferenceNo());
        date.setText(booking.getPickupDatetime());
        fromCity.setText(booking.getPickupLocation());
        toCity.setText(booking.getDropLocation());

        ok.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        startActivity(new Intent(getActivity(),HomeActivity.class));
        getActivity().finish();
    }
}
