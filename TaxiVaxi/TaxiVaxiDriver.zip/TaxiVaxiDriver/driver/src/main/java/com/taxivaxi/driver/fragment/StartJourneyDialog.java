package com.taxivaxi.driver.fragment;


import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.taxivaxi.driver.R;
import com.taxivaxi.driver.utility.NetworkStatus;
import com.taxivaxi.driver.viewmodels.CurrentBookingViewModel;

/**
 * A simple {@link Fragment} subclass.
 */
public class StartJourneyDialog extends DialogFragment implements View.OnClickListener{

    View view;

    EditText startKm;
    EditText otp;
    Button startJourney;
    String startOtp;
    CurrentBookingViewModel currentBookingViewModel;
    StartRideListener startRideListener;

    public StartJourneyDialog() {
        // Required empty public constructor
    }


    public void addStartRideListener(StartRideListener startRideListener){
        this.startRideListener=startRideListener;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_start_journey_dialog, container, false);
        startKm=view.findViewById(R.id.start_km);
        otp=view.findViewById(R.id.start_otp);
        startJourney=view.findViewById(R.id.startTrip);
        startJourney.setOnClickListener(this);
        currentBookingViewModel= ViewModelProviders.of(this).get(CurrentBookingViewModel.class);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.startTrip:
                if (NetworkStatus.isInternetConnected(getActivity().getApplication())) {
                    if (startKm.getText() != null && startKm.getText().toString().length() > 0
                            && otp.getText() != null && otp.getText().length() > 0) {
                        if (currentBookingViewModel.isStartOtpVerified(otp.getText().toString())) {
                            startRideListener.onStartRideClicked(startKm.getText().toString());
                            dismiss();
                        } else {
                            Snackbar.make(view, "Please Enter Correct OTP", Snackbar.LENGTH_LONG).show();
                        }
                    } else {
                        if (startKm.getText() == null || startKm.getText().toString().length() == 0) {
                            Snackbar.make(view, "Start Km is Required Field", Snackbar.LENGTH_LONG).show();
                        } else if (otp.getText() == null || otp.getText().toString().length() == 0) {
                            Snackbar.make(view, "OTP is Required Field", Snackbar.LENGTH_LONG).show();
                        }
                    }
                }
                else {
                    Snackbar.make(view, "Internet Connection Unavailable", Snackbar.LENGTH_LONG).show();
                }
        }

    }

    public interface StartRideListener{
        void onStartRideClicked(String startkm);
    }
}
