package com.taxivaxi.driver.retrofit;

import com.taxivaxi.driver.models.archivedbooking.ArchivedBookingApiResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by sandeep on 6/2/18.
 */

public interface ArchivedBookingAPI {

    @FormUrlEncoded
    @POST(ApiURLs.archivedBookingURL)
    Call<ArchivedBookingApiResponse> getArchivedBookings(@Field("access_token") String accessToken);
}
